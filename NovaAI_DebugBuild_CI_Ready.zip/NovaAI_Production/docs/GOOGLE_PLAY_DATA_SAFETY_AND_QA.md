# Google Play release checklist — Nova AI

## Current app data flow
- No Firebase SDKs or Firebase services are included.
- No account registration or Google Sign-In is provided.
- Conversations and preferences are stored locally using Room and DataStore.
- When Gemini is configured, prompts and user-selected attachments are transmitted to the configured HTTPS AI endpoint for response generation. The endpoint/provider may process request content under its own terms.
- No analytics or crash-reporting SDK is enabled.

## Before publishing
- Deploy and verify a server-side Gemini proxy; never embed a production API key in the APK.
- Host a privacy policy that accurately identifies the operator, contact email, AI provider, data sent, retention, deletion, and user rights.
- Complete Play Console Data Safety based on the final endpoint/provider behavior and actual app traffic.
- Test data export, local history deletion, account-free operation, offline behavior, permission prompts, and accessibility.
- Verify target SDK and all Play policy requirements at submission time.
