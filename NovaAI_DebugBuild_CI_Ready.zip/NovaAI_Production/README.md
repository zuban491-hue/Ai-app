# Nova AI — Android AI Assistant

Nova AI is a native Android application built with Kotlin, Jetpack Compose, Material 3, Hilt, Room and DataStore. It runs in local Guest Mode and does not use Firebase, Firestore, Firebase Authentication, Firebase Analytics, Crashlytics, or App Check.

## Local data
- Chat conversations and messages: Room database on this device.
- App preferences: Android DataStore.
- No account, cloud backup, cross-device sync, analytics, or crash reporting is enabled.

## Gemini API configuration
The app needs a Gemini-compatible HTTPS endpoint to generate AI responses. Configure `GEMINI_API_ENDPOINT` in `local.properties` as a complete `generateContent` endpoint. The proxy must accept the Gemini REST `generateContent` request shape and return the standard Gemini response JSON. The current client displays the completed response in incremental UI chunks; it is not server-side token streaming. `GEMINI_API_KEY` may be set for local development only. **Do not ship a production API key inside an APK**: APK secrets can be extracted. For Play Store production, deploy a server-side API proxy that authenticates/rate-limits requests and stores the Gemini key on the server, then configure the endpoint to that proxy.

Example `local.properties` (development only):
```properties
GEMINI_API_ENDPOINT=https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent
GEMINI_API_KEY=YOUR_DEVELOPMENT_KEY
```

## Build
Use JDK 17 and Android SDK 37 with Android Gradle Plugin/Kotlin versions pinned in the version catalog.

```bash
./gradlew testDebugUnitTest assembleDebug
```

Before Play Store release, configure a private upload keystore, a production proxy, verified privacy-policy hosting, accurate Data Safety declarations, app icon/screenshots, and complete Play Console testing. SDK 37 / current toolchain compatibility must be verified with an actual build environment.

## Build a Debug APK with GitHub Actions
1. Push this project to a GitHub repository.
2. Open **Actions** → **Build NovaAI Debug APK**.
3. Select **Run workflow** (or push to `main` / `master`).
4. Wait for the `debug-apk` job to finish successfully.
5. Open the run's **Artifacts** section and download `NovaAI-debug-apk`.

The APK is produced only after the workflow successfully installs Android SDK 37, runs the unit tests, and completes `assembleDebug`.
