package com.novaai.assistant.domain

import com.novaai.assistant.domain.repository.AuthRepository
import com.novaai.assistant.domain.repository.ChatRepository
import com.novaai.assistant.domain.usecase.DeleteAccountCompleteUseCase
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertTrue
import org.junit.Test

class DeleteAccountUseCaseTest {

    @Test
    fun `account deletion aborts if cloud data deletion fails`() = runTest {
        val authRepo = mockk<AuthRepository>(relaxed = true)
        val chatRepo = mockk<ChatRepository>()
        coEvery { chatRepo.deleteAllUserData("uid_1") } returns Result.failure(IllegalStateException("Firestore offline"))

        val useCase = DeleteAccountCompleteUseCase(authRepo, chatRepo)
        val result = useCase("uid_1")

        assertTrue(result.isFailure)
        coVerify(exactly = 0) { authRepo.deleteAuthAccount() }
    }

    @Test
    fun `account deletion deletes data first then removes auth account`() = runTest {
        val authRepo = mockk<AuthRepository>()
        val chatRepo = mockk<ChatRepository>()
        coEvery { chatRepo.deleteAllUserData("uid_1") } returns Result.success(Unit)
        coEvery { authRepo.deleteAuthAccount() } returns Result.success(Unit)

        val useCase = DeleteAccountCompleteUseCase(authRepo, chatRepo)
        val result = useCase("uid_1")

        assertTrue(result.isSuccess)
        coVerify(exactly = 1) { chatRepo.deleteAllUserData("uid_1") }
        coVerify(exactly = 1) { authRepo.deleteAuthAccount() }
    }
}
