package com.novaai.assistant.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SecuritySanitizerTest {

    @Test
    fun `safeLogger redacts emails and API tokens`() {
        val raw = "User alice@example.com failed with key AIzaSyDummySecretToken1234567890"
        val redacted = SafeLogger.redact(raw)
        assertFalse(redacted.contains("alice@example.com"))
        assertFalse(redacted.contains("AIzaSyDummySecretToken1234567890"))
        assertTrue(redacted.contains("[REDACTED_EMAIL]"))
        assertTrue(redacted.contains("[REDACTED_TOKEN]"))
    }

    @Test
    fun `inputSanitizer normalizes multiline titles`() {
        val title = InputSanitizer.sanitizeTitle("Line 1\nLine 2\r\nLine 3")
        assertEquals("Line 1 Line 2 Line 3", title)
    }
}
