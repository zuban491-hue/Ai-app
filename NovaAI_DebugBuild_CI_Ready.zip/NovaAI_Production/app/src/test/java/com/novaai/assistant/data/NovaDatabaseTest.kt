package com.novaai.assistant.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.novaai.assistant.data.local.db.NovaDatabase
import com.novaai.assistant.data.local.entity.ConversationEntity
import com.novaai.assistant.data.local.entity.MessageEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class NovaDatabaseTest {

    private lateinit var db: NovaDatabase

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, NovaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `deleting conversation cascades to messages and isolates users`() = runTest {
        val conv1 = ConversationEntity("c1", "userA", "Kotlin Help", 100L, 200L, false, "gemini-2.5-flash", "Hi")
        val conv2 = ConversationEntity("c2", "userB", "Private Chat", 100L, 200L, false, "gemini-2.5-flash", "Secret")
        db.conversationDao().upsertConversation(conv1)
        db.conversationDao().upsertConversation(conv2)

        db.messageDao().insertMessage(
            MessageEntity("m1", "c1", "userA", "USER", "Hello", 101L, "gemini-2.5-flash", 5, 0, "", "", "", "NONE", "", false)
        )

        val userAConvs = db.conversationDao().observeActiveConversations("userA").first()
        assertEquals(1, userAConvs.size)
        assertEquals("c1", userAConvs.first().id)

        db.conversationDao().deleteConversationById("c1")
        val msgsAfterCascade = db.messageDao().getMessagesForConversationSync("c1")
        assertEquals(0, msgsAfterCascade.size)
    }
}
