package com.novaai.assistant.presentation.chat

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaai.assistant.ai.document.DocumentAttachmentProcessor
import com.novaai.assistant.ai.speech.VoiceAndSpeechManager
import com.novaai.assistant.domain.model.AttachmentInfo
import com.novaai.assistant.domain.model.AttachmentType
import com.novaai.assistant.domain.model.ChatMessage
import com.novaai.assistant.domain.model.Conversation
import com.novaai.assistant.domain.model.GeminiModelOption
import com.novaai.assistant.domain.model.MessageRole
import com.novaai.assistant.domain.repository.AiStreamEvent
import com.novaai.assistant.domain.repository.AuthRepository
import com.novaai.assistant.domain.repository.ChatRepository
import com.novaai.assistant.domain.repository.GeminiAiRepository
import com.novaai.assistant.domain.repository.SettingsRepository
import com.novaai.assistant.domain.usecase.SendPromptUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ChatUiState(
    val activeConversationId: String? = null,
    val selectedModelId: String = "gemini-2.5-flash",
    val streamingDraftText: String = "",
    val isStreaming: Boolean = false,
    val pendingAttachment: AttachmentInfo = AttachmentInfo(),
    val searchQuery: String = "",
    val snackbarMessage: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class ChatViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val chatRepository: ChatRepository,
    private val geminiAiRepository: GeminiAiRepository,
    private val settingsRepository: SettingsRepository,
    private val sendPromptUseCase: SendPromptUseCase,
    private val attachmentProcessor: DocumentAttachmentProcessor,
    val voiceAndSpeechManager: VoiceAndSpeechManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    val availableModels: List<GeminiModelOption> = geminiAiRepository.getAvailableModels()

    private val activeUserIdFlow = authRepository.currentUser.flatMapLatest { user ->
        flowOf(user?.uid ?: "local_guest_user")
    }

    val activeConversations: StateFlow<List<Conversation>> = combine(
        activeUserIdFlow,
        _uiState
    ) { uid, state -> uid to state.searchQuery }
        .flatMapLatest { (uid, query) ->
            if (query.isBlank()) {
                chatRepository.observeConversations(uid, includeArchived = false)
            } else {
                chatRepository.searchConversations(uid, query)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val archivedConversations: StateFlow<List<Conversation>> = activeUserIdFlow
        .flatMapLatest { uid -> chatRepository.observeArchivedConversations(uid) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val messages: StateFlow<List<ChatMessage>> = _uiState
        .flatMapLatest { state ->
            val convId = state.activeConversationId
            if (convId.isNullOrBlank()) flowOf(emptyList())
            else chatRepository.observeMessages(convId, limit = 120)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var streamingJob: Job? = null

    init {
        viewModelScope.launch {
            val prefs = settingsRepository.userPreferences.first()
            _uiState.value = _uiState.value.copy(selectedModelId = prefs.selectedModelId)
        }
    }

    private fun currentUid(): String = authRepository.getCurrentUserSync()?.uid ?: "local_guest_user"

    fun selectConversation(conversationId: String?) {
        stopGeneration()
        _uiState.value = _uiState.value.copy(
            activeConversationId = conversationId,
            streamingDraftText = "",
            isStreaming = false
        )
    }

    fun startNewConversation() {
        stopGeneration()
        _uiState.value = _uiState.value.copy(
            activeConversationId = null,
            streamingDraftText = "",
            isStreaming = false,
            pendingAttachment = AttachmentInfo()
        )
    }

    fun selectModel(modelId: String) {
        _uiState.value = _uiState.value.copy(selectedModelId = modelId)
        viewModelScope.launch {
            settingsRepository.updateSelectedModel(modelId)
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun clearSnackbar() {
        _uiState.value = _uiState.value.copy(snackbarMessage = null)
    }

    fun attachUri(uri: Uri) {
        viewModelScope.launch {
            val info = attachmentProcessor.inspectUri(uri)
            _uiState.value = _uiState.value.copy(pendingAttachment = info)
        }
    }

    fun clearAttachment() {
        _uiState.value = _uiState.value.copy(pendingAttachment = AttachmentInfo())
    }

    fun renameConversation(conversationId: String, newTitle: String) {
        viewModelScope.launch {
            chatRepository.renameConversation(currentUid(), conversationId, newTitle)
        }
    }

    fun archiveConversation(conversationId: String, archived: Boolean) {
        viewModelScope.launch {
            chatRepository.setConversationArchived(currentUid(), conversationId, archived)
            if (archived && _uiState.value.activeConversationId == conversationId) {
                startNewConversation()
            }
        }
    }

    fun deleteConversation(conversationId: String) {
        viewModelScope.launch {
            chatRepository.deleteConversation(currentUid(), conversationId)
            if (_uiState.value.activeConversationId == conversationId) {
                startNewConversation()
            }
        }
    }

    fun sendMessage(rawPrompt: String) {
        if (_uiState.value.isStreaming) return
        val attachment = _uiState.value.pendingAttachment
        if (rawPrompt.isBlank() && attachment.type == AttachmentType.NONE) return

        val uid = currentUid()
        val modelId = _uiState.value.selectedModelId

        streamingJob = viewModelScope.launch {
            val convId = _uiState.value.activeConversationId ?: run {
                val created = chatRepository.createConversation(
                    userId = uid,
                    modelId = modelId,
                    initialTitle = rawPrompt.ifBlank { attachment.fileName }
                )
                _uiState.value = _uiState.value.copy(activeConversationId = created.id)
                created.id
            }

            val historySnapshot = messages.value
            val prefs = settingsRepository.userPreferences.first()

            sendPromptUseCase.recordUserPrompt(
                userId = uid,
                conversationId = convId,
                rawPrompt = rawPrompt,
                attachment = attachment
            )

            _uiState.value = _uiState.value.copy(
                pendingAttachment = AttachmentInfo(),
                isStreaming = true,
                streamingDraftText = ""
            )

            executeStream(
                uid = uid,
                convId = convId,
                modelId = modelId,
                systemInstruction = prefs.systemInstruction,
                history = historySnapshot,
                prompt = rawPrompt,
                attachment = attachment
            )
        }
    }

    fun regenerateLastResponse() {
        if (_uiState.value.isStreaming) return
        val convId = _uiState.value.activeConversationId ?: return
        val currentMessages = messages.value
        val lastUserMsg = currentMessages.lastOrNull { it.role == MessageRole.USER } ?: return
        val historyBeforeLastUser = currentMessages.takeWhile { it.id != lastUserMsg.id }
        val uid = currentUid()
        val modelId = _uiState.value.selectedModelId

        streamingJob = viewModelScope.launch {
            chatRepository.deleteLastAssistantIfError(convId)
            val prefs = settingsRepository.userPreferences.first()
            _uiState.value = _uiState.value.copy(isStreaming = true, streamingDraftText = "")
            executeStream(
                uid = uid,
                convId = convId,
                modelId = modelId,
                systemInstruction = prefs.systemInstruction,
                history = historyBeforeLastUser,
                prompt = lastUserMsg.content,
                attachment = lastUserMsg.attachment
            )
        }
    }

    fun stopGeneration() {
        streamingJob?.cancel()
        val draft = _uiState.value.streamingDraftText
        val convId = _uiState.value.activeConversationId
        if (draft.isNotBlank() && !convId.isNullOrBlank()) {
            val uid = currentUid()
            val modelId = _uiState.value.selectedModelId
            viewModelScope.launch {
                chatRepository.saveAssistantMessage(
                    userId = uid,
                    conversationId = convId,
                    content = "$draft\n\n*(Generation stopped)*",
                    modelUsed = modelId,
                    promptTokens = 0,
                    responseTokens = 0,
                    isError = false
                )
            }
        }
        _uiState.value = _uiState.value.copy(isStreaming = false, streamingDraftText = "")
    }

    private suspend fun executeStream(
        uid: String,
        convId: String,
        modelId: String,
        systemInstruction: String,
        history: List<ChatMessage>,
        prompt: String,
        attachment: AttachmentInfo
    ) {
        val builder = StringBuilder()
        sendPromptUseCase.streamAiReply(
            modelId = modelId,
            systemInstruction = systemInstruction,
            history = history,
            rawPrompt = prompt,
            attachment = attachment
        ).collect { event ->
            when (event) {
                is AiStreamEvent.Chunk -> {
                    builder.append(event.textDelta)
                    _uiState.value = _uiState.value.copy(streamingDraftText = builder.toString())
                }
                is AiStreamEvent.Completed -> {
                    chatRepository.saveAssistantMessage(
                        userId = uid,
                        conversationId = convId,
                        content = event.fullText,
                        modelUsed = modelId,
                        promptTokens = event.promptTokens,
                        responseTokens = event.responseTokens,
                        isError = false
                    )
                    _uiState.value = _uiState.value.copy(isStreaming = false, streamingDraftText = "")
                }
                is AiStreamEvent.Error -> {
                    chatRepository.saveAssistantMessage(
                        userId = uid,
                        conversationId = convId,
                        content = event.userMessage,
                        modelUsed = modelId,
                        promptTokens = 0,
                        responseTokens = 0,
                        isError = true
                    )
                    _uiState.value = _uiState.value.copy(
                        isStreaming = false,
                        streamingDraftText = "",
                        snackbarMessage = event.userMessage
                    )
                }
            }
        }
    }
}
