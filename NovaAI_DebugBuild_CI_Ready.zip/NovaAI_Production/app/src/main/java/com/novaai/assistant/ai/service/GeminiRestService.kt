package com.novaai.assistant.ai.service

import android.content.Context
import android.util.Base64
import com.novaai.assistant.BuildConfig
import com.novaai.assistant.domain.model.AttachmentInfo
import com.novaai.assistant.domain.model.AttachmentType
import com.novaai.assistant.domain.model.ChatMessage
import com.novaai.assistant.domain.model.GeminiModelOption
import com.novaai.assistant.domain.model.MessageRole
import com.novaai.assistant.domain.repository.AiStreamEvent
import com.novaai.assistant.domain.repository.GeminiAiRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GeminiRestService @Inject constructor(
    @ApplicationContext private val context: Context
) : GeminiAiRepository {

    override fun getAvailableModels(): List<GeminiModelOption> = listOf(
        GeminiModelOption("gemini-2.5-flash", "Gemini 2.5 Flash", "Fast multimodal assistant", true, true),
        GeminiModelOption("gemini-2.5-pro", "Gemini 2.5 Pro", "Advanced reasoning and analysis", true, true)
    )

    override fun streamResponse(
        modelId: String,
        systemInstruction: String,
        history: List<ChatMessage>,
        prompt: String,
        attachment: AttachmentInfo
    ): Flow<AiStreamEvent> = flow {
        try {
            val endpoint = BuildConfig.GEMINI_API_ENDPOINT.trim()
            if (endpoint.isBlank()) {
                emit(AiStreamEvent.Error("AI service is not configured. The app operator must configure a secure Gemini API proxy endpoint.", false))
                return@flow
            }
            val result = withContext(Dispatchers.IO) {
                val target = endpoint.replace("gemini-2.5-flash", modelId.ifBlank { "gemini-2.5-flash" })
                val url = if (BuildConfig.GEMINI_API_KEY.isNotBlank() && !target.contains("key=")) {
                    target + (if (target.contains("?")) "&" else "?") + "key=${BuildConfig.GEMINI_API_KEY}"
                } else target
                val contents = JSONArray()
                history.takeLast(20).filter { !it.isError && it.content.isNotBlank() }.forEach { message ->
                    contents.put(JSONObject().put("role", if (message.role == MessageRole.USER) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", message.content))))
                }
                val parts = JSONArray()
                val promptText = buildString {
                    append(prompt)
                    if (attachment.extractedTextPreview.isNotBlank()) {
                        append("\n\nAttached file (${attachment.fileName}):\n")
                        append(attachment.extractedTextPreview.take(80_000))
                    }
                }
                parts.put(JSONObject().put("text", promptText))
                if (attachment.type == AttachmentType.IMAGE && attachment.uriString.isNotBlank()) {
                    val uri = android.net.Uri.parse(attachment.uriString)
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    if (bytes != null && bytes.size <= 8 * 1024 * 1024) {
                        parts.put(JSONObject().put("inlineData", JSONObject()
                            .put("mimeType", attachment.mimeType.ifBlank { "image/jpeg" })
                            .put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))))
                    }
                }
                contents.put(JSONObject().put("role", "user").put("parts", parts))
                val body = JSONObject().put("contents", contents)
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put(
                        "text", "You are Nova AI, a helpful, accurate assistant. Reply in the user's language. Use Markdown when useful. ${systemInstruction.take(4000)}"
                    ))))
                    .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 8192))
                val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20_000
                    readTimeout = 90_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                try {
                    connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    val status = connection.responseCode
                    val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                    val response = stream.bufferedReader().use { it.readText() }
                    if (status !in 200..299) {
                        val message = runCatching { JSONObject(response).optJSONObject("error")?.optString("message") }.getOrNull()
                        error(message?.takeIf { it.isNotBlank() } ?: "AI service returned HTTP $status")
                    }
                    val json = JSONObject(response)
                    val text = json.optJSONArray("candidates")?.optJSONObject(0)
                        ?.optJSONObject("content")?.optJSONArray("parts")?.let { p ->
                            buildString { for (i in 0 until p.length()) append(p.optJSONObject(i)?.optString("text").orEmpty()) }
                        }.orEmpty()
                    if (text.isBlank()) error("The AI service returned an empty response.")
                    val usage = json.optJSONObject("usageMetadata")
                    Triple(text, usage?.optInt("promptTokenCount", 0) ?: 0, usage?.optInt("candidatesTokenCount", 0) ?: 0)
                } finally { connection.disconnect() }
            }
            // Flow-compatible incremental display. For true token streaming, the proxy must expose SSE.
            result.first.chunked(120).forEach { emit(AiStreamEvent.Chunk(it)) }
            emit(AiStreamEvent.Completed(result.first, result.second, result.third))
        } catch (t: Throwable) {
            emit(AiStreamEvent.Error(t.message?.take(240) ?: "Unable to reach the AI service. Check your internet connection.", true))
        }
    }
}
