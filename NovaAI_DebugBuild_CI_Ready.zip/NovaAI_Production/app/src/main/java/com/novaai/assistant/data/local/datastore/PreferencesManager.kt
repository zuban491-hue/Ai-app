package com.novaai.assistant.data.local.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.novaai.assistant.domain.model.AppLanguage
import com.novaai.assistant.domain.model.AppThemeMode
import com.novaai.assistant.domain.model.TextScaleOption
import com.novaai.assistant.domain.model.UserPreferences
import com.novaai.assistant.domain.repository.SettingsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

private val Context.novaDataStore by preferencesDataStore(name = "nova_ai_preferences")

@Singleton
class PreferencesManager @Inject constructor(
    @ApplicationContext private val context: Context
) : SettingsRepository {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val LANGUAGE = stringPreferencesKey("app_language")
        val TEXT_SCALE = stringPreferencesKey("text_scale")
        val SELECTED_MODEL = stringPreferencesKey("selected_model")
        val HAPTIC_ENABLED = booleanPreferencesKey("haptic_enabled")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val ANALYTICS_CONSENT = booleanPreferencesKey("analytics_consent")
        val CRASHLYTICS_CONSENT = booleanPreferencesKey("crashlytics_consent")
        val AI_DISCLOSURE_ACCEPTED = booleanPreferencesKey("ai_disclosure_accepted")
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val SYSTEM_INSTRUCTION = stringPreferencesKey("system_instruction")
    }

    override val userPreferences: Flow<UserPreferences> = context.novaDataStore.data.map { prefs ->
        UserPreferences(
            themeMode = runCatching {
                AppThemeMode.valueOf(prefs[Keys.THEME_MODE] ?: AppThemeMode.SYSTEM.name)
            }.getOrDefault(AppThemeMode.SYSTEM),
            language = runCatching {
                AppLanguage.valueOf(prefs[Keys.LANGUAGE] ?: AppLanguage.ENGLISH.name)
            }.getOrDefault(AppLanguage.ENGLISH),
            textScale = runCatching {
                TextScaleOption.valueOf(prefs[Keys.TEXT_SCALE] ?: TextScaleOption.MEDIUM.name)
            }.getOrDefault(TextScaleOption.MEDIUM),
            selectedModelId = prefs[Keys.SELECTED_MODEL] ?: "gemini-2.5-flash",
            hapticFeedbackEnabled = prefs[Keys.HAPTIC_ENABLED] ?: true,
            notificationsEnabled = prefs[Keys.NOTIFICATIONS_ENABLED] ?: false,
            analyticsConsentGiven = prefs[Keys.ANALYTICS_CONSENT] ?: false,
            crashlyticsConsentGiven = prefs[Keys.CRASHLYTICS_CONSENT] ?: false,
            aiProcessingDisclosureAccepted = prefs[Keys.AI_DISCLOSURE_ACCEPTED] ?: false,
            onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false,
            systemInstruction = prefs[Keys.SYSTEM_INSTRUCTION] ?: ""
        )
    }

    override suspend fun updateThemeMode(mode: AppThemeMode) {
        context.novaDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    override suspend fun updateLanguage(language: AppLanguage) {
        context.novaDataStore.edit { it[Keys.LANGUAGE] = language.name }
    }

    override suspend fun updateTextScale(scale: TextScaleOption) {
        context.novaDataStore.edit { it[Keys.TEXT_SCALE] = scale.name }
    }

    override suspend fun updateSelectedModel(modelId: String) {
        context.novaDataStore.edit { it[Keys.SELECTED_MODEL] = modelId }
    }

    override suspend fun updateHapticFeedback(enabled: Boolean) {
        context.novaDataStore.edit { it[Keys.HAPTIC_ENABLED] = enabled }
    }

    override suspend fun updateNotifications(enabled: Boolean) {
        context.novaDataStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = enabled }
    }

    override suspend fun updateConsent(analytics: Boolean, crashlytics: Boolean, aiDisclosure: Boolean) {
        context.novaDataStore.edit {
            it[Keys.ANALYTICS_CONSENT] = analytics
            it[Keys.CRASHLYTICS_CONSENT] = crashlytics
            it[Keys.AI_DISCLOSURE_ACCEPTED] = aiDisclosure
        }
    }

    override suspend fun setOnboardingCompleted(completed: Boolean) {
        context.novaDataStore.edit { it[Keys.ONBOARDING_COMPLETED] = completed }
    }

    override suspend fun updateSystemInstruction(instruction: String) {
        context.novaDataStore.edit { it[Keys.SYSTEM_INSTRUCTION] = instruction }
    }

    override suspend fun clearLocalCache(): Long {
        var clearedBytes = 0L
        fun deleteDir(dir: File?) {
            if (dir == null || !dir.exists()) return
            dir.listFiles()?.forEach { child ->
                if (child.isDirectory) {
                    deleteDir(child)
                } else {
                    clearedBytes += child.length()
                    child.delete()
                }
            }
        }
        deleteDir(context.cacheDir)
        return clearedBytes
    }
}
