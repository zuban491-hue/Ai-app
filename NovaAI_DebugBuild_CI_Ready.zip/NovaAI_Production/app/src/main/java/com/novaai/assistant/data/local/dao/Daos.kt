package com.novaai.assistant.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.novaai.assistant.data.local.entity.ConversationEntity
import com.novaai.assistant.data.local.entity.MessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {

    @Query("SELECT * FROM conversations WHERE userId = :userId AND isArchived = 0 ORDER BY updatedAt DESC")
    fun observeActiveConversations(userId: String): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE userId = :userId ORDER BY updatedAt DESC")
    fun observeAllConversations(userId: String): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE userId = :userId AND isArchived = 1 ORDER BY updatedAt DESC")
    fun observeArchivedConversations(userId: String): Flow<List<ConversationEntity>>

    @Query(
        "SELECT DISTINCT c.* FROM conversations c " +
            "LEFT JOIN messages m ON c.id = m.conversationId " +
            "WHERE c.userId = :userId " +
            "AND (c.title LIKE '%' || :query || '%' OR m.content LIKE '%' || :query || '%') " +
            "ORDER BY c.updatedAt DESC"
    )
    fun searchConversations(userId: String, query: String): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :id LIMIT 1")
    suspend fun getConversationById(id: String): ConversationEntity?

    @Query("SELECT * FROM conversations WHERE userId = :userId")
    suspend fun getAllConversationsSync(userId: String): List<ConversationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertConversation(conversation: ConversationEntity)

    @Query("UPDATE conversations SET title = :title, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateTitle(id: String, title: String, updatedAt: Long)

    @Query("UPDATE conversations SET isArchived = :archived, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateArchived(id: String, archived: Boolean, updatedAt: Long)

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun deleteConversationById(id: String)

    @Query("DELETE FROM conversations WHERE userId = :userId")
    suspend fun deleteAllForUser(userId: String)
}

@Dao
interface MessageDao {

    @Query(
        "SELECT * FROM (" +
            "SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp DESC LIMIT :limit" +
            ") ORDER BY timestamp ASC"
    )
    fun observeMessages(conversationId: String, limit: Int): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    suspend fun getMessagesForConversationSync(conversationId: String): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE userId = :userId ORDER BY timestamp ASC")
    suspend fun getAllMessagesForUserSync(userId: String): List<MessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Query("DELETE FROM messages WHERE id = :messageId")
    suspend fun deleteMessageById(messageId: String)

    @Query("SELECT COALESCE(SUM(promptTokens), 0) FROM messages WHERE userId = :userId")
    fun observePromptTokens(userId: String): Flow<Long>

    @Query("SELECT COALESCE(SUM(responseTokens), 0) FROM messages WHERE userId = :userId")
    fun observeResponseTokens(userId: String): Flow<Long>

    @Query("SELECT COUNT(*) FROM messages WHERE userId = :userId")
    fun observeMessageCount(userId: String): Flow<Int>
}
