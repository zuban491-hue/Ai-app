package com.novaai.assistant.navigation

object NovaDestinations {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val HOME = "home"
    const val CHAT = "chat?conversationId={conversationId}&initialPrompt={initialPrompt}"
    const val HISTORY = "history"
    const val EXPLORE = "explore"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
    const val PRIVACY_POLICY = "privacy_policy"
    const val DATA_MANAGEMENT = "data_management"
    const val DELETE_ACCOUNT = "delete_account"
    const val HELP_SUPPORT = "help_support"
    const val ABOUT = "about"

    fun chatRoute(conversationId: String? = null, initialPrompt: String? = null): String {
        val cId = conversationId ?: ""
        val prompt = java.net.URLEncoder.encode(initialPrompt ?: "", "UTF-8")
        return "chat?conversationId=$cId&initialPrompt=$prompt"
    }
}
