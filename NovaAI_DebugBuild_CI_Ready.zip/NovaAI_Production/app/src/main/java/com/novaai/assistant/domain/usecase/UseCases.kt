package com.novaai.assistant.domain.usecase

import com.novaai.assistant.domain.model.AttachmentInfo
import com.novaai.assistant.domain.model.ChatMessage
import com.novaai.assistant.domain.repository.AiStreamEvent
import com.novaai.assistant.domain.repository.AuthRepository
import com.novaai.assistant.domain.repository.ChatRepository
import com.novaai.assistant.domain.repository.GeminiAiRepository
import com.novaai.assistant.security.InputSanitizer
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class SendPromptUseCase @Inject constructor(
    private val chatRepository: ChatRepository,
    private val geminiAiRepository: GeminiAiRepository
) {
    suspend fun recordUserPrompt(
        userId: String,
        conversationId: String,
        rawPrompt: String,
        attachment: AttachmentInfo
    ): ChatMessage {
        val cleanPrompt = InputSanitizer.sanitizePrompt(rawPrompt)
        return chatRepository.saveUserMessage(userId, conversationId, cleanPrompt, attachment)
    }

    fun streamAiReply(
        modelId: String,
        systemInstruction: String,
        history: List<ChatMessage>,
        rawPrompt: String,
        attachment: AttachmentInfo
    ): Flow<AiStreamEvent> {
        val cleanPrompt = InputSanitizer.sanitizePrompt(rawPrompt)
        return geminiAiRepository.streamResponse(
            modelId = modelId,
            systemInstruction = systemInstruction,
            history = history,
            prompt = cleanPrompt,
            attachment = attachment
        )
    }
}

class DeleteAccountCompleteUseCase @Inject constructor(
    private val authRepository: AuthRepository,
    private val chatRepository: ChatRepository
) {
    suspend operator fun invoke(userId: String): Result<Unit> {
        val dataDeleteResult = chatRepository.deleteAllUserData(userId)
        if (dataDeleteResult.isFailure) {
            return Result.failure(
                dataDeleteResult.exceptionOrNull()
                    ?: IllegalStateException("Failed to delete associated cloud and local records.")
            )
        }
        return authRepository.deleteAuthAccount()
    }
}
