package com.novaai.assistant.presentation.auth

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.novaai.assistant.common.components.NovaBrandBadge

@Composable
fun LoginScreen(viewModel: AuthViewModel, onLoginSuccess: () -> Unit, onNavigateToRegister: () -> Unit, onContinueOfflineGuest: () -> Unit) {
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            NovaBrandBadge(logoSize = 48.dp)
            Text("Welcome to Nova AI", style = MaterialTheme.typography.headlineMedium)
            Text("Private Guest Mode: your chats stay on this device. No online account or cloud sync is used.", style = MaterialTheme.typography.bodyLarge)
            Button(onClick = onContinueOfflineGuest, modifier = Modifier.fillMaxWidth()) { Text("Continue as Guest") }
        }
    }
}

@Composable
fun RegistrationScreen(viewModel: AuthViewModel, onRegisterSuccess: () -> Unit, onBackToLogin: () -> Unit) {
    Scaffold { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Online accounts are disabled", style = MaterialTheme.typography.headlineSmall)
            Text("Nova AI currently works in local Guest Mode. Your conversations are stored only on this device.")
            TextButton(onClick = onBackToLogin) { Text("Back") }
        }
    }
}
