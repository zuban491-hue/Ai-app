package com.novaai.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import com.novaai.assistant.navigation.NovaNavGraph
import com.novaai.assistant.presentation.settings.SettingsAndPrivacyViewModel
import com.novaai.assistant.presentation.theme.NovaAITheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settingsViewModel: SettingsAndPrivacyViewModel = hiltViewModel()
            val prefs by settingsViewModel.preferences.collectAsState()
            NovaAITheme(
                themeMode = prefs.themeMode,
                fontScaleMultiplier = prefs.textScale.scale
            ) {
                NovaNavGraph(settingsViewModel = settingsViewModel)
            }
        }
    }
}
