package com.novaai.assistant.presentation.explore

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.novaai.assistant.domain.model.ExplorePromptTemplate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreAiScreen(
    onLaunchTemplate: (ExplorePromptTemplate) -> Unit,
    onBack: () -> Unit
) {
    val templates = listOf(
        ExplorePromptTemplate(
            id = "coding",
            category = "Coding Assistant",
            title = "Android & Backend Code Architect",
            subtitle = "Generate clean Kotlin, Java, Python, or SQL with explanations",
            promptText = "Act as a senior software architect. Help me design and implement clean, well-tested code for: ",
            recommendedModel = "gemini-2.5-pro"
        ),
        ExplorePromptTemplate(
            id = "math",
            category = "Mathematics",
            title = "Step-by-Step Math Solver",
            subtitle = "Algebra, calculus, statistics, and logical proofs",
            promptText = "Solve the following mathematics problem step-by-step and verify the final answer:\n",
            recommendedModel = "gemini-2.5-pro"
        ),
        ExplorePromptTemplate(
            id = "bengali_writing",
            category = "Multilingual Writing",
            title = "বাংলা রচনা ও প্রফেশনাল ইমেইল লেখক",
            subtitle = "সাবলীল বাংলায় চিঠি, ইমেইল, প্রবন্ধ বা সারসংক্ষেপ তৈরি করুন",
            promptText = "নিচের বিষয়টির ওপর প্রাঞ্জল ও প্রফেশনাল বাংলায় একটি লেখা তৈরি করে দাও:\n",
            recommendedModel = "gemini-2.5-flash"
        ),
        ExplorePromptTemplate(
            id = "translation",
            category = "Translation",
            title = "Context-Aware Translator (EN ↔ BN)",
            subtitle = "Natural translation preserving tone and technical accuracy",
            promptText = "Translate the following text accurately between Bengali and English while preserving natural tone:\n",
            recommendedModel = "gemini-2.0-flash"
        ),
        ExplorePromptTemplate(
            id = "summary",
            category = "Summarization",
            title = "Executive Briefing & Summarizer",
            subtitle = "Distill long notes, PDFs, or articles into key bullet points",
            promptText = "Summarize the following content into clear key takeaways and action items:\n",
            recommendedModel = "gemini-2.5-flash"
        )
    )

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Explore AI Capabilities") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(templates, key = { it.id }) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onLaunchTemplate(item) }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        AssistChip(onClick = { onLaunchTemplate(item) }, label = { Text(item.category) })
                        Spacer(Modifier.height(6.dp))
                        Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(item.subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
