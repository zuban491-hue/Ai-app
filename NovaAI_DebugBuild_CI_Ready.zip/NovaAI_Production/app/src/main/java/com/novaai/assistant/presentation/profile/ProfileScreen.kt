package com.novaai.assistant.presentation.profile

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.novaai.assistant.presentation.auth.AuthViewModel
import com.novaai.assistant.presentation.settings.SettingsAndPrivacyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    authViewModel: AuthViewModel,
    settingsViewModel: SettingsAndPrivacyViewModel,
    onOpenDataManagement: () -> Unit,
    onOpenDeleteAccount: () -> Unit,
    onSignedOut: () -> Unit,
    onBack: () -> Unit
) {
    val user by authViewModel.currentUser.collectAsState()
    val tokenUsage by settingsViewModel.tokenUsage.collectAsState()
    val authState by authViewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Guest Profile & Usage") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(user?.displayName ?: "Local Preview Mode", style = MaterialTheme.typography.titleLarge)
                    Text(
                        text = user?.email?.takeIf { it.isNotBlank() } ?: "Local Guest Mode — no account",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Token & Usage Monitoring", fontWeight = FontWeight.Bold)
                    Text("Total Stored Messages: ${tokenUsage.totalMessages}")
                    Text("Total Prompt Tokens: ${tokenUsage.totalPromptTokens}")
                    Text("Total Response Tokens: ${tokenUsage.totalResponseTokens}")
                }
            }

            authState.infoMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.primary)
            }

            OutlinedButton(onClick = onOpenDataManagement, modifier = Modifier.fillMaxWidth()) {
                Text("Data Management & Export")
            }

            OutlinedButton(onClick = onOpenDeleteAccount, modifier = Modifier.fillMaxWidth()) {
                Text("Delete Local Chat Data", color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(8.dp))

        }
    }
}
