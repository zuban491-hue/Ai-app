package com.novaai.assistant.presentation.support

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.novaai.assistant.BuildConfig
import com.novaai.assistant.common.components.NovaBrandBadge

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpAndSupportScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var reportText by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Help, Support & Content Reporting") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Frequently Asked Questions", style = MaterialTheme.typography.titleLarge)
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("How does Nova AI protect my privacy?", fontWeight = FontWeight.Bold)
                    Text("AI requests use HTTPS. Conversations are stored locally on this device.")
                }
            }

            Text("Report Inappropriate AI Output or Send Feedback", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = reportText,
                onValueChange = { reportText = it; submitted = false },
                label = { Text("Describe the issue or unsafe response") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    val mailIntent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:support@novaai-assistant.example.com")
                        putExtra(Intent.EXTRA_SUBJECT, "Nova AI Safety / Feedback Report")
                        putExtra(Intent.EXTRA_TEXT, reportText)
                    }
                    runCatching { context.startActivity(mailIntent) }
                    submitted = true
                },
                enabled = reportText.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Submit Report")
            }
            if (submitted) {
                Text("Thank you. Your report draft has been prepared.", color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutApplicationScreen(
    onOpenPrivacyPolicy: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("About Nova AI") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            NovaBrandBadge(logoSize = 48.dp)
            Text("Version ${BuildConfig.VERSION_NAME} (Build ${BuildConfig.VERSION_CODE})")
            Text(
                "Nova AI is a native Android AI Assistant built with Jetpack Compose, Material 3, Clean Architecture, Hilt, Room, and Google Gemini API.",
                style = MaterialTheme.typography.bodyLarge
            )
            OutlinedButton(onClick = onOpenPrivacyPolicy, modifier = Modifier.fillMaxWidth()) {
                Text("View Privacy Policy & Terms")
            }
        }
    }
}
