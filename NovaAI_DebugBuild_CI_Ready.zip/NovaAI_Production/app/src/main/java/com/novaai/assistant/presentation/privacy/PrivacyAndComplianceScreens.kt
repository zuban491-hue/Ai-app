package com.novaai.assistant.presentation.privacy

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.novaai.assistant.presentation.settings.SettingsAndPrivacyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyPolicyScreen(
    viewModel: SettingsAndPrivacyViewModel,
    onBack: () -> Unit
) {

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Privacy Policy & Consent") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Nova AI Privacy Policy & Terms", style = MaterialTheme.typography.titleLarge)
            Text(
                """
                1. Data Collection & Purpose
                Nova AI does not require an online account. Conversation history and app preferences are stored locally on your device.

                2. Third-Party AI Processing
                Prompts, attached images, PDFs, and text documents are transmitted over encrypted TLS/HTTPS connections to Google Gemini API. Do not share passwords, financial secrets, or government identification numbers.

                3. Data Retention & Deletion
                Your conversation history remains on this device until you delete individual conversations, clear all history, or uninstall the app.

                4. Security & Integrity
                AI prompts and attachments are sent to Google Gemini over HTTPS to generate responses. Review Google’s AI terms and privacy information before sending sensitive content.
                """.trimIndent(),
                style = MaterialTheme.typography.bodyMedium
            )

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Diagnostics & Analytics", fontWeight = FontWeight.Bold)
                    Text("This build does not include analytics or crash-reporting SDKs. No usage analytics or crash reports are collected by Nova AI.")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DataManagementScreen(
    viewModel: SettingsAndPrivacyViewModel,
    onBack: () -> Unit
) {
    val state by viewModel.privacyState.collectAsState()
    val context = LocalContext.current
    var confirmClearAll by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Data Management") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                "Export a portable JSON copy of your conversations or permanently erase your stored chat history.",
                style = MaterialTheme.typography.bodyMedium
            )

            Button(
                onClick = { viewModel.exportAllUserData() },
                enabled = !state.isBusy,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Export My Data (JSON)")
            }

            state.exportedJson?.let { json ->
                OutlinedButton(
                    onClick = {
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "application/json"
                            putExtra(Intent.EXTRA_SUBJECT, "Nova AI Data Export")
                            putExtra(Intent.EXTRA_TEXT, json)
                        }
                        context.startActivity(Intent.createChooser(intent, "Export Nova AI Data"))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Share / Save Exported JSON File")
                }
            }

            OutlinedButton(
                onClick = { confirmClearAll = true },
                enabled = !state.isBusy,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Delete All Conversation History", color = MaterialTheme.colorScheme.error)
            }

            if (state.isBusy) CircularProgressIndicator()
            state.statusMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
            state.errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }

    if (confirmClearAll) {
        AlertDialog(
            onDismissRequest = { confirmClearAll = false },
            title = { Text("Delete All History?") },
            text = { Text("This permanently deletes all your conversations from both this device and Cloud Firestore.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClearAll = false
                    viewModel.deleteAllConversations()
                }) { Text("Delete All", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClearAll = false }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeleteAccountScreen(
    viewModel: SettingsAndPrivacyViewModel,
    onAccountDeleted: () -> Unit,
    onBack: () -> Unit
) {
    val state by viewModel.privacyState.collectAsState()
    var confirmationText by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Delete Local Data") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                "Permanent Local Data Deletion",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.error
            )
            Text(
                "Nova AI uses Guest Mode and has no online account to delete. Clear local chat history or uninstall the app to remove locally stored conversations.",
                style = MaterialTheme.typography.bodyMedium
            )

            OutlinedTextField(
                value = confirmationText,
                onValueChange = { confirmationText = it },
                label = { Text("Type DELETE to confirm") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = { viewModel.deleteAccountCompletely(onAccountDeleted) },
                enabled = confirmationText.trim() == "DELETE" && !state.isBusy,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Permanently Delete Local Data")
            }

            Spacer(Modifier.height(8.dp))


            if (state.isBusy) CircularProgressIndicator()
            state.statusMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
            state.errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}
