package com.novaai.assistant.ai.document

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import com.novaai.assistant.domain.model.AttachmentInfo
import com.novaai.assistant.domain.model.AttachmentType
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DocumentAttachmentProcessor @Inject constructor(
    @ApplicationContext private val context: Context
) {

    suspend fun inspectUri(uri: Uri): AttachmentInfo = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val mime = resolver.getType(uri) ?: "application/octet-stream"
        var displayName = "attachment"
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) displayName = cursor.getString(idx) ?: displayName
            }
        }

        val type = when {
            mime.startsWith("image/") -> AttachmentType.IMAGE
            mime == "application/pdf" || displayName.endsWith(".pdf", true) -> AttachmentType.PDF
            mime.startsWith("text/") || displayName.endsWith(".txt", true) ||
                displayName.endsWith(".md", true) || displayName.endsWith(".csv", true) ||
                displayName.endsWith(".json", true) -> AttachmentType.TEXT
            else -> AttachmentType.TEXT
        }

        val extractedPreview = when (type) {
            AttachmentType.TEXT -> readTextFromUri(uri, maxChars = 24_000)
            AttachmentType.PDF -> "PDF Document ($displayName)"
            AttachmentType.IMAGE -> "Image ($displayName)"
            AttachmentType.NONE -> ""
        }

        AttachmentInfo(
            uriString = uri.toString(),
            fileName = displayName,
            mimeType = mime,
            type = type,
            extractedTextPreview = extractedPreview
        )
    }

    suspend fun loadScaledBitmap(uriString: String, maxDimension: Int = 1280): Bitmap? = withContext(Dispatchers.IO) {
        runCatching {
            val uri = Uri.parse(uriString)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            var sampleSize = 1
            while (bounds.outWidth / sampleSize > maxDimension || bounds.outHeight / sampleSize > maxDimension) {
                sampleSize *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOpts)
            }
        }.getOrNull()
    }

    suspend fun renderPdfPagesAsBitmaps(uriString: String, maxPages: Int = 4): List<Bitmap> = withContext(Dispatchers.IO) {
        val bitmaps = mutableListOf<Bitmap>()
        runCatching {
            val uri = Uri.parse(uriString)
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                PdfRenderer(pfd).use { renderer ->
                    val count = minOf(renderer.pageCount, maxPages)
                    for (i in 0 until count) {
                        renderer.openPage(i).use { page ->
                            val bmp = Bitmap.createBitmap(page.width, page.height, Bitmap.Config.ARGB_8888)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            bitmaps.add(bmp)
                        }
                    }
                }
            }
        }
        bitmaps
    }

    private fun readTextFromUri(uri: Uri, maxChars: Int): String {
        return runCatching {
            context.contentResolver.openInputStream(uri)?.use { input ->
                BufferedReader(InputStreamReader(input)).use { reader ->
                    val sb = StringBuilder()
                    var line: String?
                    while (reader.readLine().also { line = it } != null && sb.length < maxChars) {
                        sb.append(line).append('\n')
                    }
                    sb.toString().take(maxChars)
                }
            } ?: ""
        }.getOrDefault("")
    }
}
