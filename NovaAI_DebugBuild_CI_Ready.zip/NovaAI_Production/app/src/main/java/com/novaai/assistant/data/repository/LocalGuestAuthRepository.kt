package com.novaai.assistant.data.repository

import com.novaai.assistant.domain.model.UserProfile
import com.novaai.assistant.domain.repository.AuthRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LocalGuestAuthRepository @Inject constructor() : AuthRepository {
    private val guest = UserProfile(uid = "local-guest", email = "", displayName = "Guest User", isGuest = true)
    private val user = MutableStateFlow<UserProfile?>(guest)
    override val currentUser: Flow<UserProfile?> = user
    override fun getCurrentUserSync(): UserProfile? = user.value
    override suspend fun signInWithEmail(email: String, password: String) = Result.failure<UserProfile>(UnsupportedOperationException("Nova AI uses private local Guest Mode; online accounts are not enabled."))
    override suspend fun registerWithEmail(name: String, email: String, password: String) = Result.failure<UserProfile>(UnsupportedOperationException("Account registration is not available in local-only mode."))
    override suspend fun signInWithGoogleIdToken(idToken: String) = Result.failure<UserProfile>(UnsupportedOperationException("Google Sign-In is disabled in local-only mode."))
    override suspend fun sendPasswordReset(email: String) = Result.failure<Unit>(UnsupportedOperationException("Password reset is unavailable because no online account is used."))
    override suspend fun sendEmailVerification() = Result.failure<Unit>(UnsupportedOperationException("Email verification is unavailable in Guest Mode."))
    override suspend fun reloadUser() = Result.success(user.value)
    override suspend fun signOut() { user.value = guest }
    override suspend fun deleteAuthAccount() { user.value = null; user.value = guest; }
}
