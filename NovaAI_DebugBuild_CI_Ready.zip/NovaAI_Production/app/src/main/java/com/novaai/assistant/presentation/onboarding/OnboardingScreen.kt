package com.novaai.assistant.presentation.onboarding

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.novaai.assistant.common.components.NovaBrandBadge

@Composable
fun OnboardingScreen(
    onFinished: (analyticsConsent: Boolean, crashlyticsConsent: Boolean) -> Unit,
    onOpenPrivacyPolicy: () -> Unit
) {
    var aiDisclosureAccepted by remember { mutableStateOf(false) }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            NovaBrandBadge(logoSize = 40.dp)

            Text(
                text = "Welcome to Nova AI",
                style = MaterialTheme.typography.headlineMedium
            )
            Text(
                text = "Your multilingual AI companion for coding, research, document analysis, voice conversations, and writing in Bengali, English, and more.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Third-Party AI Processing & Privacy", fontWeight = FontWeight.Bold)
                    Text(
                        text = "When you send prompts, images, or documents, they are transmitted securely over HTTPS to Google Gemini API to generate responses. Do not submit passwords, banking PINs, or sensitive government IDs.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    TextButton(onClick = onOpenPrivacyPolicy) {
                        Text("Read Full Privacy Policy & Terms")
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = aiDisclosureAccepted,
                    onCheckedChange = { aiDisclosureAccepted = it }
                )
                Text(
                    text = "I understand that my prompts are processed by Google Gemini AI and agree to the Privacy Policy.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                "No usage analytics or crash-reporting SDK is included. Your chats are saved locally on this device.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = { onFinished(false, false) },
                enabled = aiDisclosureAccepted,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text("Continue to Nova AI")
            }
        }
    }
}
