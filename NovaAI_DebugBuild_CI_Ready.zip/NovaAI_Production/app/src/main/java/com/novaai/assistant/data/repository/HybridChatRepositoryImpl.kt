package com.novaai.assistant.data.repository

import com.novaai.assistant.data.local.dao.ConversationDao
import com.novaai.assistant.data.local.dao.MessageDao
import com.novaai.assistant.data.local.entity.ConversationEntity
import com.novaai.assistant.data.local.entity.MessageEntity
import com.novaai.assistant.domain.model.AttachmentInfo
import com.novaai.assistant.domain.model.AttachmentType
import com.novaai.assistant.domain.model.ChatMessage
import com.novaai.assistant.domain.model.Conversation
import com.novaai.assistant.domain.model.MessageRole
import com.novaai.assistant.domain.model.TokenUsageSummary
import com.novaai.assistant.domain.repository.ChatRepository
import com.novaai.assistant.security.InputSanitizer
import com.novaai.assistant.security.SafeLogger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HybridChatRepositoryImpl @Inject constructor(
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao
) : ChatRepository {

    private fun ConversationEntity.toDomain(): Conversation = Conversation(
        id = id,
        userId = userId,
        title = title,
        createdAt = createdAt,
        updatedAt = updatedAt,
        isArchived = isArchived,
        modelId = modelId,
        lastMessagePreview = lastMessagePreview
    )

    private fun MessageEntity.toDomain(): ChatMessage = ChatMessage(
        id = id,
        conversationId = conversationId,
        role = runCatching { MessageRole.valueOf(role) }.getOrDefault(MessageRole.USER),
        content = content,
        timestamp = timestamp,
        modelUsed = modelUsed,
        promptTokens = promptTokens,
        responseTokens = responseTokens,
        attachment = AttachmentInfo(
            uriString = attachmentUri,
            fileName = attachmentName,
            mimeType = attachmentMime,
            type = runCatching { AttachmentType.valueOf(attachmentType) }.getOrDefault(AttachmentType.NONE),
            extractedTextPreview = attachmentPreview
        ),
        isError = isError
    )

    override fun observeConversations(userId: String, includeArchived: Boolean): Flow<List<Conversation>> {
        val source = if (includeArchived) {
            conversationDao.observeAllConversations(userId)
        } else {
            conversationDao.observeActiveConversations(userId)
        }
        return source.map { list -> list.map { it.toDomain() } }
    }

    override fun observeArchivedConversations(userId: String): Flow<List<Conversation>> {
        return conversationDao.observeArchivedConversations(userId).map { list -> list.map { it.toDomain() } }
    }

    override fun searchConversations(userId: String, query: String): Flow<List<Conversation>> {
        return conversationDao.searchConversations(userId, query.trim()).map { list -> list.map { it.toDomain() } }
    }

    override fun observeMessages(conversationId: String, limit: Int): Flow<List<ChatMessage>> {
        return messageDao.observeMessages(conversationId, limit).map { list -> list.map { it.toDomain() } }
    }

    override fun observeTokenUsage(userId: String): Flow<TokenUsageSummary> {
        return combine(
            messageDao.observePromptTokens(userId),
            messageDao.observeResponseTokens(userId),
            messageDao.observeMessageCount(userId)
        ) { prompt, response, count ->
            TokenUsageSummary(
                totalPromptTokens = prompt,
                totalResponseTokens = response,
                totalMessages = count
            )
        }
    }

    override suspend fun createConversation(
        userId: String,
        modelId: String,
        initialTitle: String
    ): Conversation {
        val now = System.currentTimeMillis()
        val entity = ConversationEntity(
            id = UUID.randomUUID().toString(),
            userId = userId,
            title = InputSanitizer.sanitizeTitle(initialTitle),
            createdAt = now,
            updatedAt = now,
            isArchived = false,
            modelId = modelId,
            lastMessagePreview = ""
        )
        conversationDao.upsertConversation(entity)
        return entity.toDomain()
    }

    override suspend fun renameConversation(userId: String, conversationId: String, newTitle: String) {
        val now = System.currentTimeMillis()
        val sanitized = InputSanitizer.sanitizeTitle(newTitle)
        conversationDao.updateTitle(conversationId, sanitized, now)

    }

    override suspend fun setConversationArchived(userId: String, conversationId: String, archived: Boolean) {
        val now = System.currentTimeMillis()
        conversationDao.updateArchived(conversationId, archived, now)
    }

    override suspend fun deleteConversation(userId: String, conversationId: String) {
        conversationDao.deleteConversationById(conversationId)
    }

    override suspend fun deleteAllUserData(userId: String): Result<Unit> = runCatching {
        conversationDao.deleteAllForUser(userId)
        SafeLogger.d("ChatRepo", "Deleted all local records for guest user")
    }

    override suspend fun exportUserDataJson(userId: String): Result<String> = runCatching {
        val conversations = conversationDao.getAllConversationsSync(userId)
        val root = JSONObject().apply {
            put("application", "Nova AI")
            put("exportedAtEpochMs", System.currentTimeMillis())
            put("userId", userId)
        }
        val convArray = JSONArray()
        for (conv in conversations) {
            val cObj = JSONObject().apply {
                put("id", conv.id)
                put("title", conv.title)
                put("createdAt", conv.createdAt)
                put("updatedAt", conv.updatedAt)
                put("isArchived", conv.isArchived)
                put("modelId", conv.modelId)
            }
            val msgArray = JSONArray()
            val msgs = messageDao.getMessagesForConversationSync(conv.id)
            for (m in msgs) {
                msgArray.put(JSONObject().apply {
                    put("id", m.id)
                    put("role", m.role)
                    put("content", m.content)
                    put("timestamp", m.timestamp)
                    put("modelUsed", m.modelUsed)
                    put("promptTokens", m.promptTokens)
                    put("responseTokens", m.responseTokens)
                })
            }
            cObj.put("messages", msgArray)
            convArray.put(cObj)
        }
        root.put("conversations", convArray)
        root.toString(2)
    }

    override suspend fun saveUserMessage(
        userId: String,
        conversationId: String,
        content: String,
        attachment: AttachmentInfo
    ): ChatMessage {
        val now = System.currentTimeMillis()
        val existingConv = conversationDao.getConversationById(conversationId)
        val isFirst = existingConv == null || existingConv.lastMessagePreview.isBlank()
        val autoTitle = if (isFirst) {
            InputSanitizer.sanitizeTitle(content.ifBlank { attachment.fileName.ifBlank { "New Conversation" } })
        } else {
            existingConv?.title ?: "New Conversation"
        }

        val updatedConv = ConversationEntity(
            id = conversationId,
            userId = userId,
            title = autoTitle,
            createdAt = existingConv?.createdAt ?: now,
            updatedAt = now,
            isArchived = existingConv?.isArchived ?: false,
            modelId = existingConv?.modelId ?: "gemini-2.5-flash",
            lastMessagePreview = content.take(90)
        )
        conversationDao.upsertConversation(updatedConv)

        val msgEntity = MessageEntity(
            id = UUID.randomUUID().toString(),
            conversationId = conversationId,
            userId = userId,
            role = MessageRole.USER.name,
            content = content,
            timestamp = now,
            modelUsed = updatedConv.modelId,
            promptTokens = 0,
            responseTokens = 0,
            attachmentUri = attachment.uriString,
            attachmentName = attachment.fileName,
            attachmentMime = attachment.mimeType,
            attachmentType = attachment.type.name,
            attachmentPreview = attachment.extractedTextPreview.take(400),
            isError = false
        )
        messageDao.insertMessage(msgEntity)
        return msgEntity.toDomain()
    }

    override suspend fun saveAssistantMessage(
        userId: String,
        conversationId: String,
        content: String,
        modelUsed: String,
        promptTokens: Int,
        responseTokens: Int,
        isError: Boolean
    ): ChatMessage {
        val now = System.currentTimeMillis()
        val existingConv = conversationDao.getConversationById(conversationId)
        if (existingConv != null && !isError) {
            val updated = existingConv.copy(updatedAt = now, lastMessagePreview = content.take(90))
            conversationDao.upsertConversation(updated)
        }

        val msgEntity = MessageEntity(
            id = UUID.randomUUID().toString(),
            conversationId = conversationId,
            userId = userId,
            role = MessageRole.ASSISTANT.name,
            content = content,
            timestamp = now,
            modelUsed = modelUsed,
            promptTokens = promptTokens,
            responseTokens = responseTokens,
            attachmentUri = "",
            attachmentName = "",
            attachmentMime = "",
            attachmentType = AttachmentType.NONE.name,
            attachmentPreview = "",
            isError = isError
        )
        messageDao.insertMessage(msgEntity)
        return msgEntity.toDomain()
    }

    override suspend fun deleteLastAssistantIfError(conversationId: String) {
        val msgs = messageDao.getMessagesForConversationSync(conversationId)
        val last = msgs.lastOrNull()
        if (last != null && last.role == MessageRole.ASSISTANT.name && last.isError) {
            messageDao.deleteMessageById(last.id)
        }
    }

    override suspend fun syncFromCloud(userId: String) = Unit
}
