package com.novaai.assistant.security

import android.util.Log
import com.novaai.assistant.BuildConfig

object SafeLogger {
    private val EMAIL_REGEX = Regex("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")
    private val TOKEN_REGEX = Regex("(AIza[0-9A-Za-z-_]{20,}|eyJ[0-9A-Za-z._-]{20,})")
    fun d(tag: String, message: String) { if (BuildConfig.DEBUG) Log.d(tag, redact(message)) }
    fun e(tag: String, message: String, throwable: Throwable? = null, crashlyticsEnabled: Boolean = false) {
        if (BuildConfig.DEBUG) Log.e(tag, redact(message), throwable)
    }
    fun redact(input: String): String = input.replace(EMAIL_REGEX, "[REDACTED_EMAIL]").replace(TOKEN_REGEX, "[REDACTED_TOKEN]")
}
