package com.novaai.assistant.security

object InputSanitizer {
    private const val MAX_PROMPT_LENGTH = 32_000
    private const val MAX_TITLE_LENGTH = 80

    fun sanitizePrompt(raw: String): String {
        val trimmed = raw.trim()
        return if (trimmed.length > MAX_PROMPT_LENGTH) {
            trimmed.take(MAX_PROMPT_LENGTH)
        } else {
            trimmed
        }
    }

    fun sanitizeTitle(raw: String): String {
        val singleLine = raw.replace(Regex("[\r\n]+"), " ").trim()
        return singleLine.take(MAX_TITLE_LENGTH).ifBlank { "New Conversation" }
    }
}
