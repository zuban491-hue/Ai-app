package com.novaai.assistant.presentation.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.novaai.assistant.domain.model.AppLanguage
import com.novaai.assistant.domain.model.AppThemeMode
import com.novaai.assistant.domain.model.TextScaleOption

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsAndPrivacyViewModel,
    onNavigateRoute: (String) -> Unit,
    onBack: () -> Unit
) {
    val prefs by viewModel.preferences.collectAsState()
    val privacyState by viewModel.privacyState.collectAsState()
    var customInstruction by remember(prefs.systemInstruction) { mutableStateOf(prefs.systemInstruction) }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Settings & Personalization") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Appearance Theme", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = prefs.themeMode == mode,
                        onClick = { viewModel.setThemeMode(mode) },
                        label = { Text(mode.name) }
                    )
                }
            }

            Text("App Language", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppLanguage.entries.take(2).forEach { lang ->
                    FilterChip(
                        selected = prefs.language == lang,
                        onClick = { viewModel.setLanguage(lang) },
                        label = { Text(lang.label) }
                    )
                }
            }

            Text("Text Size", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextScaleOption.entries.forEach { opt ->
                    FilterChip(
                        selected = prefs.textScale == opt,
                        onClick = { viewModel.setTextScale(opt) },
                        label = { Text(opt.label) }
                    )
                }
            }

            Text("Custom Chat Preference (System Instruction)", fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = customInstruction,
                onValueChange = { customInstruction = it },
                placeholder = { Text("e.g., Always explain code concisely in Bengali...") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = { viewModel.setSystemInstruction(customInstruction) }) {
                Text("Save Chat Preference")
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Haptic Feedback")
                Switch(checked = prefs.hapticFeedbackEnabled, onCheckedChange = { viewModel.setHapticFeedback(it) })
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Notifications")
                Switch(checked = prefs.notificationsEnabled, onCheckedChange = { viewModel.setNotifications(it) })
            }

            privacyState.statusMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.primary)
            }

            OutlinedButton(onClick = { viewModel.clearCache() }, modifier = Modifier.fillMaxWidth()) {
                Text("Clear Temporary Cache")
            }

            HorizontalDivider()

            ListItem(
                headlineContent = { Text("Privacy Policy & Consent Controls") },
                modifier = Modifier.clickable { onNavigateRoute("privacy_policy") }
            )
            ListItem(
                headlineContent = { Text("Data Management & Export") },
                modifier = Modifier.clickable { onNavigateRoute("data_management") }
            )
            ListItem(
                headlineContent = { Text("Delete Account", color = MaterialTheme.colorScheme.error) },
                modifier = Modifier.clickable { onNavigateRoute("delete_account") }
            )
            ListItem(
                headlineContent = { Text("Help & Support") },
                modifier = Modifier.clickable { onNavigateRoute("help_support") }
            )
            ListItem(
                headlineContent = { Text("About Nova AI") },
                modifier = Modifier.clickable { onNavigateRoute("about") }
            )
        }
    }
}
