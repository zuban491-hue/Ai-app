package com.novaai.assistant.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.novaai.assistant.data.local.dao.ConversationDao
import com.novaai.assistant.data.local.dao.MessageDao
import com.novaai.assistant.data.local.entity.ConversationEntity
import com.novaai.assistant.data.local.entity.MessageEntity

@Database(
    entities = [ConversationEntity::class, MessageEntity::class],
    version = 1,
    exportSchema = false
)
abstract class NovaDatabase : RoomDatabase() {
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
}
