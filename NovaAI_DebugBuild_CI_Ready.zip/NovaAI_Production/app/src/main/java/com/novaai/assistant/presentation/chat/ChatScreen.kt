package com.novaai.assistant.presentation.chat

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.automirrored.outlined.VolumeUp
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.novaai.assistant.common.components.MarkdownMessageRenderer
import com.novaai.assistant.common.components.NovaBrandBadge
import com.novaai.assistant.domain.model.AttachmentType
import com.novaai.assistant.domain.model.ChatMessage
import com.novaai.assistant.domain.model.MessageRole
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    initialConversationId: String?,
    initialPrompt: String?,
    hapticsEnabled: Boolean,
    onNavigateRoute: (String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val conversations by viewModel.activeConversations.collectAsState()
    val isListening by viewModel.voiceAndSpeechManager.isListening.collectAsState()

    var inputText by remember { mutableStateOf("") }
    var modelMenuExpanded by remember { mutableStateOf(false) }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val snackbarHostState = remember { SnackbarHostState() }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current

    LaunchedEffect(initialConversationId) {
        if (!initialConversationId.isNullOrBlank()) {
            viewModel.selectConversation(initialConversationId)
        }
    }

    LaunchedEffect(initialPrompt) {
        if (!initialPrompt.isNullOrBlank()) {
            inputText = initialPrompt
        }
    }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    LaunchedEffect(messages.size, uiState.streamingDraftText) {
        val total = messages.size + if (uiState.isStreaming) 1 else 0
        if (total > 0) {
            listState.animateScrollToItem(total - 1)
        }
    }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.attachUri(uri)
    }

    val docPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) viewModel.attachUri(uri)
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.voiceAndSpeechManager.startListening(
                onResultText = { spoken -> inputText = spoken },
                onError = { err -> scope.launch { snackbarHostState.showSnackbar(err) } }
            )
        } else {
            scope.launch { snackbarHostState.showSnackbar("Microphone permission is needed for voice input.") }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    NovaBrandBadge(logoSize = 32.dp)
                    Spacer(Modifier.height(6.dp))

                    OutlinedButton(
                        onClick = {
                            viewModel.startNewConversation()
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Outlined.Add, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("New Conversation")
                    }

                    Text(
                        "Recent Chats",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp)
                    )

                    LazyColumn(modifier = Modifier.weight(1f)) {
                        items(conversations, key = { it.id }) { conv ->
                            NavigationDrawerItem(
                                label = { Text(conv.title, maxLines = 1) },
                                selected = conv.id == uiState.activeConversationId,
                                onClick = {
                                    viewModel.selectConversation(conv.id)
                                    scope.launch { drawerState.close() }
                                }
                            )
                        }
                    }

                    HorizontalDivider()

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Outlined.History, null) },
                        label = { Text("Chat History & Search") },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onNavigateRoute("history")
                        }
                    )
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Outlined.Explore, null) },
                        label = { Text("Explore AI") },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onNavigateRoute("explore")
                        }
                    )
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Outlined.Person, null) },
                        label = { Text("Profile") },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onNavigateRoute("profile")
                        }
                    )
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Outlined.Settings, null) },
                        label = { Text("Settings & Privacy") },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onNavigateRoute("settings")
                        }
                    )
                }
            }
        }
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Outlined.Menu, contentDescription = "Open navigation drawer")
                        }
                    },
                    title = {
                        Box {
                            AssistChip(
                                onClick = { modelMenuExpanded = true },
                                label = { Text(uiState.selectedModelId) }
                            )
                            DropdownMenu(
                                expanded = modelMenuExpanded,
                                onDismissRequest = { modelMenuExpanded = false }
                            ) {
                                viewModel.availableModels.forEach { option ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(option.displayName, fontWeight = FontWeight.Bold)
                                                Text(
                                                    option.description,
                                                    style = MaterialTheme.typography.labelMedium
                                                )
                                            }
                                        },
                                        onClick = {
                                            viewModel.selectModel(option.id)
                                            modelMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.startNewConversation() }) {
                            Icon(Icons.Outlined.Add, contentDescription = "New Chat")
                        }
                    }
                )
            },
            bottomBar = {
                ChatComposerBar(
                    text = inputText,
                    onTextChange = { inputText = it },
                    pendingAttachmentName = uiState.pendingAttachment.fileName.takeIf {
                        uiState.pendingAttachment.type != AttachmentType.NONE
                    },
                    onClearAttachment = { viewModel.clearAttachment() },
                    isStreaming = uiState.isStreaming,
                    isListening = isListening,
                    onPickImage = {
                        imagePickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickDocument = {
                        docPickerLauncher.launch(arrayOf("application/pdf", "text/*"))
                    },
                    onToggleVoice = {
                        if (isListening) {
                            viewModel.voiceAndSpeechManager.stopListening()
                        } else {
                            val perm = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                            if (perm == PackageManager.PERMISSION_GRANTED) {
                                viewModel.voiceAndSpeechManager.startListening(
                                    onResultText = { spoken -> inputText = spoken },
                                    onError = { err -> scope.launch { snackbarHostState.showSnackbar(err) } }
                                )
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    onSend = {
                        if (hapticsEnabled) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        }
                        val outgoing = inputText
                        inputText = ""
                        viewModel.sendMessage(outgoing)
                    },
                    onStop = { viewModel.stopGeneration() }
                )
            }
        ) { padding ->
            if (messages.isEmpty() && !uiState.isStreaming) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    NovaBrandBadge(logoSize = 54.dp, showTitle = false)
                    Spacer(Modifier.height(14.dp))
                    Text("How can I help you today?", style = MaterialTheme.typography.headlineMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Ask anything in Bengali or English, attach an image or PDF, or use voice input.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        ChatBubbleItem(
                            message = msg,
                            onCopy = {
                                clipboard.setText(AnnotatedString(msg.content))
                                scope.launch { snackbarHostState.showSnackbar("Copied to clipboard") }
                            },
                            onShare = {
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, msg.content)
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Share AI Response"))
                            },
                            onSpeak = { viewModel.voiceAndSpeechManager.speak(msg.content) },
                            onRegenerate = { viewModel.regenerateLastResponse() }
                        )
                    }

                    if (uiState.isStreaming) {
                        item(key = "streaming_bubble") {
                            StreamingAssistantBubble(draftText = uiState.streamingDraftText)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatBubbleItem(
    message: ChatMessage,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onSpeak: () -> Unit,
    onRegenerate: () -> Unit
) {
    val isUser = message.role == MessageRole.USER
    if (isUser) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.fillMaxWidth(0.84f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    if (message.attachment.type != AttachmentType.NONE) {
                        Text(
                            text = "Attached: ${message.attachment.fileName}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(4.dp))
                    }
                    Text(
                        text = message.content,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }
    } else {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            NovaBrandBadge(logoSize = 28.dp, showTitle = false)
            Column(modifier = Modifier.weight(1f)) {
                MarkdownMessageRenderer(
                    markdown = message.content,
                    textColor = if (message.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )
                if (message.promptTokens > 0 || message.responseTokens > 0) {
                    Text(
                        text = "Tokens: ${message.promptTokens} in / ${message.responseTokens} out • ${message.modelUsed}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onCopy) {
                        Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy response", modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onShare) {
                        Icon(Icons.Outlined.Share, contentDescription = "Share response", modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onSpeak) {
                        Icon(Icons.AutoMirrored.Outlined.VolumeUp, contentDescription = "Read aloud", modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onRegenerate) {
                        Icon(Icons.Outlined.Refresh, contentDescription = "Regenerate response", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun StreamingAssistantBubble(draftText: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top
    ) {
        NovaBrandBadge(logoSize = 28.dp, showTitle = false)
        Column(modifier = Modifier.weight(1f)) {
            if (draftText.isBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Nova AI is thinking...", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                MarkdownMessageRenderer(markdown = draftText)
            }
        }
    }
}

@Composable
private fun ChatComposerBar(
    text: String,
    onTextChange: (String) -> Unit,
    pendingAttachmentName: String?,
    onClearAttachment: () -> Unit,
    isStreaming: Boolean,
    isListening: Boolean,
    onPickImage: () -> Unit,
    onPickDocument: () -> Unit,
    onToggleVoice: () -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit
) {
    Surface(
        tonalElevation = 3.dp,
        modifier = Modifier
            .fillMaxWidth()
            .imePadding()
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            if (pendingAttachmentName != null) {
                Row(
                    modifier = Modifier
                        .padding(bottom = 6.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = pendingAttachmentName,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onClearAttachment, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Outlined.Close, contentDescription = "Remove attachment")
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                IconButton(onClick = onPickImage) {
                    Icon(Icons.Outlined.Image, contentDescription = "Upload Image")
                }
                IconButton(onClick = onPickDocument) {
                    Icon(Icons.Outlined.AttachFile, contentDescription = "Upload PDF or Text Document")
                }
                OutlinedTextField(
                    value = text,
                    onValueChange = onTextChange,
                    placeholder = { Text("Message Nova AI...") },
                    maxLines = 5,
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onToggleVoice) {
                    Icon(
                        imageVector = Icons.Outlined.Mic,
                        contentDescription = "Voice Input",
                        tint = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                    )
                }
                if (isStreaming) {
                    IconButton(
                        onClick = onStop,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Icon(Icons.Outlined.Stop, contentDescription = "Stop Generation")
                    }
                } else {
                    IconButton(
                        onClick = onSend,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Outlined.Send,
                            contentDescription = "Send Message",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        }
    }
}
