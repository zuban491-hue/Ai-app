package com.novaai.assistant.domain.repository

import com.novaai.assistant.domain.model.AttachmentInfo
import com.novaai.assistant.domain.model.ChatMessage
import com.novaai.assistant.domain.model.Conversation
import com.novaai.assistant.domain.model.GeminiModelOption
import com.novaai.assistant.domain.model.TokenUsageSummary
import com.novaai.assistant.domain.model.UserPreferences
import com.novaai.assistant.domain.model.UserProfile
import kotlinx.coroutines.flow.Flow

interface AuthRepository {
    val currentUser: Flow<UserProfile?>
    fun getCurrentUserSync(): UserProfile?
    suspend fun signInWithEmail(email: String, password: String): Result<UserProfile>
    suspend fun registerWithEmail(name: String, email: String, password: String): Result<UserProfile>
    suspend fun signInWithGoogleIdToken(idToken: String): Result<UserProfile>
    suspend fun sendPasswordReset(email: String): Result<Unit>
    suspend fun sendEmailVerification(): Result<Unit>
    suspend fun reloadUser(): Result<UserProfile?>
    suspend fun signOut()
    suspend fun deleteAuthAccount(): Result<Unit>
}

interface ChatRepository {
    fun observeConversations(userId: String, includeArchived: Boolean = false): Flow<List<Conversation>>
    fun observeArchivedConversations(userId: String): Flow<List<Conversation>>
    fun searchConversations(userId: String, query: String): Flow<List<Conversation>>
    fun observeMessages(conversationId: String, limit: Int = 100): Flow<List<ChatMessage>>
    fun observeTokenUsage(userId: String): Flow<TokenUsageSummary>

    suspend fun createConversation(userId: String, modelId: String, initialTitle: String = "New Conversation"): Conversation
    suspend fun renameConversation(userId: String, conversationId: String, newTitle: String)
    suspend fun setConversationArchived(userId: String, conversationId: String, archived: Boolean)
    suspend fun deleteConversation(userId: String, conversationId: String)
    suspend fun deleteAllUserData(userId: String): Result<Unit>
    suspend fun exportUserDataJson(userId: String): Result<String>

    suspend fun saveUserMessage(
        userId: String,
        conversationId: String,
        content: String,
        attachment: AttachmentInfo
    ): ChatMessage

    suspend fun saveAssistantMessage(
        userId: String,
        conversationId: String,
        content: String,
        modelUsed: String,
        promptTokens: Int,
        responseTokens: Int,
        isError: Boolean = false
    ): ChatMessage

    suspend fun deleteLastAssistantIfError(conversationId: String)
    suspend fun syncFromCloud(userId: String)
}

interface GeminiAiRepository {
    fun getAvailableModels(): List<GeminiModelOption>
    fun streamResponse(
        modelId: String,
        systemInstruction: String,
        history: List<ChatMessage>,
        prompt: String,
        attachment: AttachmentInfo
    ): Flow<AiStreamEvent>
}

sealed interface AiStreamEvent {
    data class Chunk(val textDelta: String) : AiStreamEvent
    data class Completed(
        val fullText: String,
        val promptTokens: Int,
        val responseTokens: Int
    ) : AiStreamEvent
    data class Error(val userMessage: String, val isRetryable: Boolean = true) : AiStreamEvent
}

interface SettingsRepository {
    val userPreferences: Flow<UserPreferences>
    suspend fun updateThemeMode(mode: com.novaai.assistant.domain.model.AppThemeMode)
    suspend fun updateLanguage(language: com.novaai.assistant.domain.model.AppLanguage)
    suspend fun updateTextScale(scale: com.novaai.assistant.domain.model.TextScaleOption)
    suspend fun updateSelectedModel(modelId: String)
    suspend fun updateHapticFeedback(enabled: Boolean)
    suspend fun updateNotifications(enabled: Boolean)
    suspend fun updateConsent(analytics: Boolean, crashlytics: Boolean, aiDisclosure: Boolean)
    suspend fun setOnboardingCompleted(completed: Boolean)
    suspend fun updateSystemInstruction(instruction: String)
    suspend fun clearLocalCache(): Long
}
