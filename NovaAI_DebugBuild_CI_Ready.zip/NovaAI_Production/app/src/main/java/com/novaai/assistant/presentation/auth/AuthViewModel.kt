package com.novaai.assistant.presentation.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaai.assistant.domain.model.UserProfile
import com.novaai.assistant.domain.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AuthUiState(
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val infoMessage: String? = null
)

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository,
) : ViewModel() {

    val currentUser: StateFlow<UserProfile?> = authRepository.currentUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), authRepository.getCurrentUserSync())

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun clearMessages() {
        _uiState.value = _uiState.value.copy(errorMessage = null, infoMessage = null)
    }

    fun signInWithEmail(email: String, password: String, onSuccess: () -> Unit) {
        if (email.isBlank() || password.length < 6) {
            _uiState.value = AuthUiState(errorMessage = "Enter a valid email and a password with at least 6 characters.")
            return
        }
        viewModelScope.launch {
            _uiState.value = AuthUiState(isLoading = true)
            authRepository.signInWithEmail(email, password)
                .onSuccess { user ->
                    _uiState.value = AuthUiState(isLoading = false)
                    onSuccess()
                }
                .onFailure { err ->
                    _uiState.value = AuthUiState(isLoading = false, errorMessage = err.message ?: "Sign-in failed.")
                }
        }
    }

    fun registerWithEmail(name: String, email: String, password: String, onSuccess: () -> Unit) {
        if (name.isBlank() || email.isBlank() || password.length < 6) {
            _uiState.value = AuthUiState(errorMessage = "Complete all fields (password must be at least 6 characters).")
            return
        }
        viewModelScope.launch {
            _uiState.value = AuthUiState(isLoading = true)
            authRepository.registerWithEmail(name, email, password)
                .onSuccess {
                    _uiState.value = AuthUiState(
                        isLoading = false,
                        infoMessage = "Account created! Verification email sent."
                    )
                    onSuccess()
                }
                .onFailure { err ->
                    _uiState.value = AuthUiState(isLoading = false, errorMessage = err.message ?: "Registration failed.")
                }
        }
    }

    fun handleGoogleIdToken(idToken: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _uiState.value = AuthUiState(isLoading = true)
            authRepository.signInWithGoogleIdToken(idToken)
                .onSuccess { user ->
                    _uiState.value = AuthUiState(isLoading = false)
                    onSuccess()
                }
                .onFailure { err ->
                    _uiState.value = AuthUiState(isLoading = false, errorMessage = err.message ?: "Google Sign-In failed.")
                }
        }
    }

    fun sendPasswordReset(email: String) {
        if (email.isBlank()) {
            _uiState.value = AuthUiState(errorMessage = "Enter your email address first to reset your password.")
            return
        }
        viewModelScope.launch {
            _uiState.value = AuthUiState(isLoading = true)
            authRepository.sendPasswordReset(email)
                .onSuccess {
                    _uiState.value = AuthUiState(
                        isLoading = false,
                        infoMessage = "Password reset link sent to $email"
                    )
                }
                .onFailure { err ->
                    _uiState.value = AuthUiState(isLoading = false, errorMessage = err.message ?: "Unable to send reset email.")
                }
        }
    }

    fun sendEmailVerification() {
        viewModelScope.launch {
            authRepository.sendEmailVerification()
                .onSuccess {
                    _uiState.value = _uiState.value.copy(infoMessage = "Verification email sent. Check your inbox.")
                }
                .onFailure { err ->
                    _uiState.value = _uiState.value.copy(errorMessage = err.message)
                }
        }
    }

    fun signOut(onSignedOut: () -> Unit) {
        viewModelScope.launch {
            authRepository.signOut()
            onSignedOut()
        }
    }
}
