package com.novaai.assistant.di

import android.content.Context
import androidx.room.Room
import com.novaai.assistant.ai.service.GeminiRestService
import com.novaai.assistant.data.local.dao.ConversationDao
import com.novaai.assistant.data.local.dao.MessageDao
import com.novaai.assistant.data.local.datastore.PreferencesManager
import com.novaai.assistant.data.local.db.NovaDatabase
import com.novaai.assistant.data.repository.LocalGuestAuthRepository
import com.novaai.assistant.data.repository.HybridChatRepositoryImpl
import com.novaai.assistant.domain.repository.AuthRepository
import com.novaai.assistant.domain.repository.ChatRepository
import com.novaai.assistant.domain.repository.GeminiAiRepository
import com.novaai.assistant.domain.repository.SettingsRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideNovaDatabase(@ApplicationContext context: Context): NovaDatabase {
        return Room.databaseBuilder(
            context,
            NovaDatabase::class.java,
            "nova_ai_production.db"
        ).fallbackToDestructiveMigration(dropAllTables = false).build()
    }

    @Provides
    fun provideConversationDao(db: NovaDatabase): ConversationDao = db.conversationDao()

    @Provides
    fun provideMessageDao(db: NovaDatabase): MessageDao = db.messageDao()
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryBindingModule {

    @Binds
    @Singleton
    abstract fun bindAuthRepository(impl: LocalGuestAuthRepository): AuthRepository

    @Binds
    @Singleton
    abstract fun bindChatRepository(impl: HybridChatRepositoryImpl): ChatRepository

    @Binds
    @Singleton
    abstract fun bindGeminiAiRepository(impl: GeminiRestService): GeminiAiRepository

    @Binds
    @Singleton
    abstract fun bindSettingsRepository(impl: PreferencesManager): SettingsRepository
}
