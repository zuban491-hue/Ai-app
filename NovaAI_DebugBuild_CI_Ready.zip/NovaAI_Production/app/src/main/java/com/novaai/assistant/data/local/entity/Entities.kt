package com.novaai.assistant.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "conversations",
    indices = [Index("userId"), Index("updatedAt")]
)
data class ConversationEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val isArchived: Boolean,
    val modelId: String,
    val lastMessagePreview: String
)

@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = ConversationEntity::class,
            parentColumns = ["id"],
            childColumns = ["conversationId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("conversationId"), Index("timestamp")]
)
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val userId: String,
    val role: String,
    val content: String,
    val timestamp: Long,
    val modelUsed: String,
    val promptTokens: Int,
    val responseTokens: Int,
    val attachmentUri: String,
    val attachmentName: String,
    val attachmentMime: String,
    val attachmentType: String,
    val attachmentPreview: String,
    val isError: Boolean
)
