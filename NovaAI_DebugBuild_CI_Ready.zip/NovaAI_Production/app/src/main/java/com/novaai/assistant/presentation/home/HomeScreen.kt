package com.novaai.assistant.presentation.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddComment
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.novaai.assistant.common.components.NovaBrandBadge
import com.novaai.assistant.domain.model.Conversation
import com.novaai.assistant.domain.model.UserProfile
import com.novaai.assistant.presentation.chat.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    user: UserProfile?,
    chatViewModel: ChatViewModel,
    onStartNewChat: (initialPrompt: String?) -> Unit,
    onOpenConversation: (String) -> Unit,
    onOpenHistory: () -> Unit,
    onOpenExplore: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val conversations by chatViewModel.activeConversations.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { NovaBrandBadge(logoSize = 30.dp) },
                actions = {
                    IconButton(onClick = onOpenExplore) {
                        Icon(Icons.Outlined.Explore, contentDescription = "Explore AI")
                    }
                    IconButton(onClick = onOpenProfile) {
                        Icon(Icons.Outlined.Person, contentDescription = "Profile")
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Outlined.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = "Hello, ${user?.displayName ?: "Explorer"}",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    text = "Start a conversation or pick up where you left off.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { onStartNewChat(null) },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                    ) {
                        Icon(Icons.Outlined.AddComment, contentDescription = null)
                        Spacer(Modifier.padding(4.dp))
                        Text("New Chat")
                    }
                    OutlinedButton(
                        onClick = onOpenExplore,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                    ) {
                        Icon(Icons.Outlined.Explore, contentDescription = null)
                        Spacer(Modifier.padding(4.dp))
                        Text("Explore AI")
                    }
                }
            }

            item {
                Text("Quick Starters", style = MaterialTheme.typography.titleMedium)
            }

            val quickPrompts = listOf(
                "Write clean Kotlin & Jetpack Compose code for a REST client",
                "বাংলায় একটি পেশাদার আবেদনপত্র লিখে দাও",
                "Solve a step-by-step calculus derivative problem",
                "Summarize key takeaways from a long technical article"
            )

            items(quickPrompts) { prompt ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onStartNewChat(prompt) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Text(
                        text = prompt,
                        modifier = Modifier.padding(14.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Recent Conversations", style = MaterialTheme.typography.titleMedium)
                    IconButton(onClick = onOpenHistory) {
                        Icon(Icons.Outlined.History, contentDescription = "View all history")
                    }
                }
            }

            if (conversations.isEmpty()) {
                item {
                    Text(
                        text = "No conversations yet. Tap 'New Chat' to begin.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            } else {
                items(conversations.take(5), key = { it.id }) { conv ->
                    ConversationSummaryCard(conv = conv, onClick = { onOpenConversation(conv.id) })
                }
            }
        }
    }
}

@Composable
private fun ConversationSummaryCard(conv: Conversation, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(conv.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
            if (conv.lastMessagePreview.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = conv.lastMessagePreview,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2
                )
            }
        }
    }
}
