package com.novaai.assistant.common.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

sealed interface MarkdownBlock {
    data class Paragraph(val text: String) : MarkdownBlock
    data class CodeBlock(val language: String, val code: String) : MarkdownBlock
    data class TableBlock(val rows: List<List<String>>) : MarkdownBlock
}

@Composable
fun MarkdownMessageRenderer(
    markdown: String,
    modifier: Modifier = Modifier,
    textColor: Color = MaterialTheme.colorScheme.onSurface
) {
    val blocks = remember(markdown) { parseMarkdownBlocks(markdown) }

    SelectionContainer {
        Column(
            modifier = modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            blocks.forEach { block ->
                when (block) {
                    is MarkdownBlock.CodeBlock -> CodeBlockCard(block)
                    is MarkdownBlock.TableBlock -> MarkdownTableCard(block, textColor)
                    is MarkdownBlock.Paragraph -> RichTextParagraph(block.text, textColor)
                }
            }
        }
    }
}

@Composable
private fun CodeBlockCard(block: MarkdownBlock.CodeBlock) {
    val clipboard = LocalClipboardManager.current
    val highlighted = remember(block.code) { highlightSyntax(block.code) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F172A))
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E293B))
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = block.language.ifBlank { "code" }.uppercase(),
                color = Color(0xFF38BDF8),
                style = MaterialTheme.typography.labelMedium
            )
            IconButton(
                onClick = { clipboard.setText(AnnotatedString(block.code)) }
            ) {
                Icon(
                    imageVector = Icons.Outlined.ContentCopy,
                    contentDescription = "Copy code",
                    tint = Color(0xFFCBD5E1)
                )
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            Text(
                text = highlighted,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                lineHeight = 19.sp
            )
        }
    }
}

@Composable
private fun MarkdownTableCard(block: MarkdownBlock.TableBlock, textColor: Color) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
    ) {
        block.rows.forEachIndexed { rowIndex, cells ->
            val isHeader = rowIndex == 0
            Row(
                modifier = Modifier.background(
                    if (isHeader) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent
                )
            ) {
                cells.forEach { cell ->
                    Text(
                        text = cell.trim(),
                        color = textColor,
                        fontWeight = if (isHeader) FontWeight.Bold else FontWeight.Normal,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun RichTextParagraph(raw: String, textColor: Color) {
    val lines = raw.lines()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        lines.forEach { line ->
            val trimmed = line.trimStart()
            when {
                trimmed.startsWith("### ") -> Text(
                    text = parseInlineStyles(trimmed.removePrefix("### ")),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = textColor
                )
                trimmed.startsWith("## ") -> Text(
                    text = parseInlineStyles(trimmed.removePrefix("## ")),
                    style = MaterialTheme.typography.titleLarge,
                    color = textColor
                )
                trimmed.startsWith("# ") -> Text(
                    text = parseInlineStyles(trimmed.removePrefix("# ")),
                    style = MaterialTheme.typography.headlineMedium,
                    color = textColor
                )
                trimmed.startsWith("- ") || trimmed.startsWith("* ") -> Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("•", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(
                        text = parseInlineStyles(trimmed.drop(2)),
                        style = MaterialTheme.typography.bodyLarge,
                        color = textColor
                    )
                }
                else -> Text(
                    text = parseInlineStyles(line),
                    style = MaterialTheme.typography.bodyLarge,
                    color = textColor
                )
            }
        }
    }
}

private fun parseInlineStyles(text: String): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < text.length) {
        when {
            text.startsWith("**", i) -> {
                val end = text.indexOf("**", i + 2)
                if (end > i + 2) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        append(text.substring(i + 2, end))
                    }
                    i = end + 2
                } else {
                    append(text[i])
                    i++
                }
            }
            text[i] == '`' -> {
                val end = text.indexOf('`', i + 1)
                if (end > i + 1) {
                    withStyle(
                        SpanStyle(
                            fontFamily = FontFamily.Monospace,
                            background = Color(0x220D9488)
                        )
                    ) {
                        append(" ${text.substring(i + 1, end)} ")
                    }
                    i = end + 1
                } else {
                    append(text[i])
                    i++
                }
            }
            else -> {
                append(text[i])
                i++
            }
        }
    }
}

private fun highlightSyntax(code: String): AnnotatedString = buildAnnotatedString {
    val keywords = setOf(
        "fun", "val", "var", "class", "object", "interface", "return", "if", "else",
        "when", "for", "while", "import", "package", "suspend", "private", "public",
        "override", "data", "sealed", "def", "const", "let", "function", "async", "await",
        "int", "String", "void", "boolean", "true", "false", "null"
    )
    val tokens = Regex("(\\b[A-Za-z_][A-Za-z0-9_]*\\b|\".*?\"|//.*|\\d+|\\s+|.)").findAll(code)
    for (match in tokens) {
        val tok = match.value
        val color = when {
            tok.startsWith("//") -> Color(0xFF64748B)
            tok.startsWith("\"") -> Color(0xFF86EFAC)
            tok in keywords -> Color(0xFF38BDF8)
            tok.all { it.isDigit() } -> Color(0xFFFBBF24)
            else -> Color(0xFFE2E8F0)
        }
        withStyle(SpanStyle(color = color)) {
            append(tok)
        }
    }
}

private fun parseMarkdownBlocks(input: String): List<MarkdownBlock> {
    val result = mutableListOf<MarkdownBlock>()
    val lines = input.lines()
    var i = 0
    val paragraphBuffer = mutableListOf<String>()

    fun flushParagraph() {
        if (paragraphBuffer.isNotEmpty()) {
            val joined = paragraphBuffer.joinToString("\n").trim()
            if (joined.isNotEmpty()) result.add(MarkdownBlock.Paragraph(joined))
            paragraphBuffer.clear()
        }
    }

    while (i < lines.size) {
        val line = lines[i]
        val trimmed = line.trim()
        if (trimmed.startsWith("```")) {
            flushParagraph()
            val lang = trimmed.removePrefix("```").trim()
            val codeLines = mutableListOf<String>()
            i++
            while (i < lines.size && !lines[i].trim().startsWith("```")) {
                codeLines.add(lines[i])
                i++
            }
            result.add(MarkdownBlock.CodeBlock(lang, codeLines.joinToString("\n")))
            i++
        } else if (trimmed.startsWith("|") && trimmed.endsWith("|")) {
            flushParagraph()
            val tableRows = mutableListOf<List<String>>()
            while (i < lines.size && lines[i].trim().startsWith("|") && lines[i].trim().endsWith("|")) {
                val rowLine = lines[i].trim().removePrefix("|").removeSuffix("|")
                val cells = rowLine.split("|")
                val isSeparator = cells.all { it.trim().matches(Regex("^[-:]+$")) }
                if (!isSeparator) {
                    tableRows.add(cells)
                }
                i++
            }
            if (tableRows.isNotEmpty()) result.add(MarkdownBlock.TableBlock(tableRows))
        } else {
            paragraphBuffer.add(line)
            i++
        }
    }
    flushParagraph()
    return result
}
