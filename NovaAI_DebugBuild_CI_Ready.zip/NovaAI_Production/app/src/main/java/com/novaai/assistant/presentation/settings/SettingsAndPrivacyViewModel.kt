package com.novaai.assistant.presentation.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaai.assistant.domain.model.AppLanguage
import com.novaai.assistant.domain.model.AppThemeMode
import com.novaai.assistant.domain.model.TextScaleOption
import com.novaai.assistant.domain.model.TokenUsageSummary
import com.novaai.assistant.domain.model.UserPreferences
import com.novaai.assistant.domain.repository.AuthRepository
import com.novaai.assistant.domain.repository.ChatRepository
import com.novaai.assistant.domain.repository.SettingsRepository
import com.novaai.assistant.domain.usecase.DeleteAccountCompleteUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class PrivacyOperationState(
    val isBusy: Boolean = false,
    val exportedJson: String? = null,
    val statusMessage: String? = null,
    val errorMessage: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class SettingsAndPrivacyViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val chatRepository: ChatRepository,
    private val authRepository: AuthRepository,
    private val deleteAccountCompleteUseCase: DeleteAccountCompleteUseCase
) : ViewModel() {

    val preferences: StateFlow<UserPreferences> = settingsRepository.userPreferences
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferences())

    val tokenUsage: StateFlow<TokenUsageSummary> = authRepository.currentUser
        .flatMapLatest { user ->
            chatRepository.observeTokenUsage(user?.uid ?: "local_guest_user")
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TokenUsageSummary())

    private val _privacyState = MutableStateFlow(PrivacyOperationState())
    val privacyState: StateFlow<PrivacyOperationState> = _privacyState.asStateFlow()

    fun setThemeMode(mode: AppThemeMode) {
        viewModelScope.launch { settingsRepository.updateThemeMode(mode) }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch { settingsRepository.updateLanguage(language) }
    }

    fun setTextScale(scale: TextScaleOption) {
        viewModelScope.launch { settingsRepository.updateTextScale(scale) }
    }

    fun setHapticFeedback(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.updateHapticFeedback(enabled) }
    }

    fun setNotifications(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.updateNotifications(enabled) }
    }

    fun setSystemInstruction(instruction: String) {
        viewModelScope.launch { settingsRepository.updateSystemInstruction(instruction) }
    }

    fun completeOnboarding() {
        viewModelScope.launch { settingsRepository.setOnboardingCompleted(true) }
    }

    fun updateConsent(analytics: Boolean, crashlytics: Boolean, aiDisclosure: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateConsent(analytics, crashlytics, aiDisclosure)
            _privacyState.value = _privacyState.value.copy(statusMessage = "Privacy preferences updated.")
        }
    }

    fun clearCache() {
        viewModelScope.launch {
            val bytes = settingsRepository.clearLocalCache()
            val kb = bytes / 1024
            _privacyState.value = _privacyState.value.copy(statusMessage = "Cleared $kb KB of temporary cache.")
        }
    }

    fun exportAllUserData() {
        viewModelScope.launch {
            _privacyState.value = PrivacyOperationState(isBusy = true)
            val uid = authRepository.getCurrentUserSync()?.uid ?: "local_guest_user"
            chatRepository.exportUserDataJson(uid)
                .onSuccess { json ->
                    _privacyState.value = PrivacyOperationState(
                        isBusy = false,
                        exportedJson = json,
                        statusMessage = "Data export generated (${json.length} characters)."
                    )
                }
                .onFailure { err ->
                    _privacyState.value = PrivacyOperationState(
                        isBusy = false,
                        errorMessage = err.message ?: "Export failed."
                    )
                }
        }
    }

    fun deleteAllConversations() {
        viewModelScope.launch {
            _privacyState.value = PrivacyOperationState(isBusy = true)
            val uid = authRepository.getCurrentUserSync()?.uid ?: "local_guest_user"
            chatRepository.deleteAllUserData(uid)
                .onSuccess {
                    _privacyState.value = PrivacyOperationState(
                        isBusy = false,
                        statusMessage = "All locally stored conversations have been permanently deleted."
                    )
                }
                .onFailure { err ->
                    _privacyState.value = PrivacyOperationState(
                        isBusy = false,
                        errorMessage = "Deletion incomplete: ${err.message}"
                    )
                }
        }
    }

    fun deleteAccountCompletely(onAccountDeleted: () -> Unit) {
        viewModelScope.launch {
            _privacyState.value = PrivacyOperationState(isBusy = true)
            val uid = authRepository.getCurrentUserSync()?.uid
            if (uid.isNullOrBlank()) {
                _privacyState.value = PrivacyOperationState(
                    isBusy = false,
                    errorMessage = "No local Guest profile is available."
                )
                return@launch
            }
            deleteAccountCompleteUseCase(uid)
                .onSuccess {
                    _privacyState.value = PrivacyOperationState(
                        isBusy = false,
                        statusMessage = "Your local conversations have been permanently deleted."
                    )
                    onAccountDeleted()
                }
                .onFailure { err ->
                    _privacyState.value = PrivacyOperationState(
                        isBusy = false,
                        errorMessage = "Local data deletion failed: ${err.message}"
                    )
                }
        }
    }
}
