package com.novaai.assistant.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.novaai.assistant.presentation.auth.AuthViewModel
import com.novaai.assistant.presentation.auth.LoginScreen
import com.novaai.assistant.presentation.auth.RegistrationScreen
import com.novaai.assistant.presentation.chat.ChatScreen
import com.novaai.assistant.presentation.chat.ChatViewModel
import com.novaai.assistant.presentation.explore.ExploreAiScreen
import com.novaai.assistant.presentation.history.ChatHistoryScreen
import com.novaai.assistant.presentation.home.HomeScreen
import com.novaai.assistant.presentation.onboarding.OnboardingScreen
import com.novaai.assistant.presentation.privacy.DataManagementScreen
import com.novaai.assistant.presentation.privacy.DeleteAccountScreen
import com.novaai.assistant.presentation.privacy.PrivacyPolicyScreen
import com.novaai.assistant.presentation.profile.ProfileScreen
import com.novaai.assistant.presentation.settings.SettingsAndPrivacyViewModel
import com.novaai.assistant.presentation.settings.SettingsScreen
import com.novaai.assistant.presentation.splash.SplashScreen
import com.novaai.assistant.presentation.support.AboutApplicationScreen
import com.novaai.assistant.presentation.support.HelpAndSupportScreen
import java.net.URLDecoder

@Composable
fun NovaNavGraph(
    settingsViewModel: SettingsAndPrivacyViewModel = hiltViewModel(),
    authViewModel: AuthViewModel = hiltViewModel(),
    chatViewModel: ChatViewModel = hiltViewModel()
) {
    val navController = rememberNavController()
    val prefs by settingsViewModel.preferences.collectAsState()
    val currentUser by authViewModel.currentUser.collectAsState()

    NavHost(
        navController = navController,
        startDestination = NovaDestinations.SPLASH
    ) {
        composable(NovaDestinations.SPLASH) {
            SplashScreen(
                onboardingCompleted = prefs.onboardingCompleted,
                isAuthenticated = currentUser != null,
                onNavigateNext = { target ->
                    navController.navigate(target) {
                        popUpTo(NovaDestinations.SPLASH) { inclusive = true }
                    }
                }
            )
        }

        composable(NovaDestinations.ONBOARDING) {
            OnboardingScreen(
                onFinished = { analytics, crashlytics ->
                    settingsViewModel.updateConsent(analytics, crashlytics, aiDisclosure = true)
                    settingsViewModel.completeOnboarding()
                    navController.navigate(NovaDestinations.LOGIN) {
                        popUpTo(NovaDestinations.ONBOARDING) { inclusive = true }
                    }
                },
                onOpenPrivacyPolicy = { navController.navigate(NovaDestinations.PRIVACY_POLICY) }
            )
        }

        composable(NovaDestinations.LOGIN) {
            LoginScreen(
                viewModel = authViewModel,
                onLoginSuccess = {
                    navController.navigate(NovaDestinations.HOME) {
                        popUpTo(NovaDestinations.LOGIN) { inclusive = true }
                    }
                },
                onNavigateToRegister = { navController.navigate(NovaDestinations.REGISTER) },
                onContinueOfflineGuest = {
                    navController.navigate(NovaDestinations.HOME) {
                        popUpTo(NovaDestinations.LOGIN) { inclusive = true }
                    }
                }
            )
        }

        composable(NovaDestinations.REGISTER) {
            RegistrationScreen(
                viewModel = authViewModel,
                onRegisterSuccess = {
                    navController.navigate(NovaDestinations.HOME) {
                        popUpTo(NovaDestinations.LOGIN) { inclusive = true }
                    }
                },
                onBackToLogin = { navController.popBackStack() }
            )
        }

        composable(NovaDestinations.HOME) {
            HomeScreen(
                user = currentUser,
                chatViewModel = chatViewModel,
                onStartNewChat = { initialPrompt ->
                    chatViewModel.startNewConversation()
                    navController.navigate(NovaDestinations.chatRoute(initialPrompt = initialPrompt))
                },
                onOpenConversation = { convId ->
                    navController.navigate(NovaDestinations.chatRoute(conversationId = convId))
                },
                onOpenHistory = { navController.navigate(NovaDestinations.HISTORY) },
                onOpenExplore = { navController.navigate(NovaDestinations.EXPLORE) },
                onOpenProfile = { navController.navigate(NovaDestinations.PROFILE) },
                onOpenSettings = { navController.navigate(NovaDestinations.SETTINGS) }
            )
        }

        composable(
            route = NovaDestinations.CHAT,
            arguments = listOf(
                navArgument("conversationId") { type = NavType.StringType; defaultValue = "" },
                navArgument("initialPrompt") { type = NavType.StringType; defaultValue = "" }
            )
        ) { backStack ->
            val convId = backStack.arguments?.getString("conversationId")?.takeIf { it.isNotBlank() }
            val rawPrompt = backStack.arguments?.getString("initialPrompt").orEmpty()
            val decodedPrompt = runCatching { URLDecoder.decode(rawPrompt, "UTF-8") }.getOrDefault(rawPrompt)
            ChatScreen(
                viewModel = chatViewModel,
                initialConversationId = convId,
                initialPrompt = decodedPrompt.takeIf { it.isNotBlank() },
                hapticsEnabled = prefs.hapticFeedbackEnabled,
                onNavigateRoute = { route -> navController.navigate(route) }
            )
        }

        composable(NovaDestinations.HISTORY) {
            ChatHistoryScreen(
                viewModel = chatViewModel,
                onSelectConversation = { convId ->
                    navController.navigate(NovaDestinations.chatRoute(conversationId = convId))
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(NovaDestinations.EXPLORE) {
            ExploreAiScreen(
                onLaunchTemplate = { template ->
                    chatViewModel.selectModel(template.recommendedModel)
                    chatViewModel.startNewConversation()
                    navController.navigate(NovaDestinations.chatRoute(initialPrompt = template.promptText))
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(NovaDestinations.PROFILE) {
            ProfileScreen(
                authViewModel = authViewModel,
                settingsViewModel = settingsViewModel,
                onOpenDataManagement = { navController.navigate(NovaDestinations.DATA_MANAGEMENT) },
                onOpenDeleteAccount = { navController.navigate(NovaDestinations.DELETE_ACCOUNT) },
                onSignedOut = {
                    navController.navigate(NovaDestinations.LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(NovaDestinations.SETTINGS) {
            SettingsScreen(
                viewModel = settingsViewModel,
                onNavigateRoute = { route -> navController.navigate(route) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(NovaDestinations.PRIVACY_POLICY) {
            PrivacyPolicyScreen(
                viewModel = settingsViewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable(NovaDestinations.DATA_MANAGEMENT) {
            DataManagementScreen(
                viewModel = settingsViewModel,
                onBack = { navController.popBackStack() }
            )
        }

        composable(NovaDestinations.DELETE_ACCOUNT) {
            DeleteAccountScreen(
                viewModel = settingsViewModel,
                onAccountDeleted = {
                    navController.navigate(NovaDestinations.LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(NovaDestinations.HELP_SUPPORT) {
            HelpAndSupportScreen(onBack = { navController.popBackStack() })
        }

        composable(NovaDestinations.ABOUT) {
            AboutApplicationScreen(
                onOpenPrivacyPolicy = { navController.navigate(NovaDestinations.PRIVACY_POLICY) },
                onBack = { navController.popBackStack() }
            )
        }
    }
}
