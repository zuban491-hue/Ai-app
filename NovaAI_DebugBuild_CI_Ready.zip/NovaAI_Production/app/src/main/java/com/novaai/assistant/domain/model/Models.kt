package com.novaai.assistant.domain.model

enum class MessageRole {
    USER,
    ASSISTANT,
    SYSTEM
}

enum class AttachmentType {
    NONE,
    IMAGE,
    PDF,
    TEXT
}

data class AttachmentInfo(
    val uriString: String = "",
    val fileName: String = "",
    val mimeType: String = "",
    val type: AttachmentType = AttachmentType.NONE,
    val extractedTextPreview: String = ""
)

data class ChatMessage(
    val id: String,
    val conversationId: String,
    val role: MessageRole,
    val content: String,
    val timestamp: Long,
    val modelUsed: String = "gemini-2.5-flash",
    val promptTokens: Int = 0,
    val responseTokens: Int = 0,
    val attachment: AttachmentInfo = AttachmentInfo(),
    val isStreaming: Boolean = false,
    val isError: Boolean = false
)

data class Conversation(
    val id: String,
    val userId: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val isArchived: Boolean = false,
    val modelId: String = "gemini-2.5-flash",
    val lastMessagePreview: String = ""
)

data class GeminiModelOption(
    val id: String,
    val displayName: String,
    val description: String,
    val supportsVision: Boolean = true,
    val supportsDocuments: Boolean = true
)

data class UserProfile(
    val uid: String,
    val email: String,
    val displayName: String,
    val photoUrl: String? = null,
    val isEmailVerified: Boolean = false,
    val isGuest: Boolean = false
)

enum class AppThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

enum class AppLanguage(val code: String, val label: String) {
    ENGLISH("en", "English"),
    BENGALI("bn", "বাংলা (Bengali)"),
    HINDI("hi", "हिन्दी (Hindi)"),
    ARABIC("ar", "العربية (Arabic)")
}

enum class TextScaleOption(val scale: Float, val label: String) {
    SMALL(0.9f, "Small"),
    MEDIUM(1.0f, "Default"),
    LARGE(1.15f, "Large"),
    EXTRA_LARGE(1.3f, "Extra Large")
}

data class UserPreferences(
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val textScale: TextScaleOption = TextScaleOption.MEDIUM,
    val selectedModelId: String = "gemini-2.5-flash",
    val hapticFeedbackEnabled: Boolean = true,
    val notificationsEnabled: Boolean = false,
    val analyticsConsentGiven: Boolean = false,
    val crashlyticsConsentGiven: Boolean = false,
    val aiProcessingDisclosureAccepted: Boolean = false,
    val onboardingCompleted: Boolean = false,
    val systemInstruction: String = ""
)

data class ExplorePromptTemplate(
    val id: String,
    val category: String,
    val title: String,
    val subtitle: String,
    val promptText: String,
    val recommendedModel: String = "gemini-2.5-flash"
)

data class TokenUsageSummary(
    val totalPromptTokens: Long = 0L,
    val totalResponseTokens: Long = 0L,
    val totalMessages: Int = 0
)
