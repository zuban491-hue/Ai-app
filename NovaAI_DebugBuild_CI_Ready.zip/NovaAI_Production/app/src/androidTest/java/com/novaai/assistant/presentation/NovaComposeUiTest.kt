package com.novaai.assistant.presentation

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.novaai.assistant.presentation.onboarding.OnboardingScreen
import com.novaai.assistant.presentation.theme.NovaAITheme
import org.junit.Rule
import org.junit.Test

class NovaComposeUiTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun onboardingDisplaysPrivacyDisclosureAndConsentToggle() {
        composeTestRule.setContent {
            NovaAITheme {
                OnboardingScreen(
                    onFinished = { _, _ -> },
                    onOpenPrivacyPolicy = {}
                )
            }
        }
        composeTestRule.onNodeWithText("Welcome to Nova AI").assertIsDisplayed()
        composeTestRule.onNodeWithText("Third-Party AI Processing & Privacy").assertIsDisplayed()
    }
}
